# AirWatch: Real-Time AQI with AI Forecast

Live air quality from WAQI, saved history, and a 24-hour forecast from a Random Forest and an LSTM.
React + Vite frontend, Flask backend.

## Run it (Windows)

1. Get a free token at https://aqicn.org/data-platform/token/
2. Double-click `start-backend.bat`. The first run installs packages and creates `backend\.env`.
   Open that file, replace `YOUR_WAQI_TOKEN` with your token, then run `start-backend.bat` again.
3. Double-click `start-frontend.bat` (second window), then open http://localhost:5173

Keep both windows open. Check the backend at http://127.0.0.1:5000/api/health

**Manual (any system)**
```bash
cd backend && python -m venv venv && venv\Scripts\activate    # Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python run.py
# second terminal
cd frontend && npm install && npm run dev
```

**Optional LSTM.** The Random Forest works out of the box. To add the LSTM:
`pip install -r requirements-lstm.txt` (CPU build: `pip install torch --index-url https://download.pytorch.org/whl/cpu`).
Without PyTorch the forecast page says the LSTM was skipped and uses the Random Forest alone.

## Pages

| Page | What it shows |
|---|---|
| Overview | AQI, weather, pollutants, 48-hour trend, AI outlook |
| Pollutants | Each pollutant's sub-index and which one drives the AQI |
| AI forecast | History + next 24 h from Random Forest, LSTM and a combined line, with an error table |
| Map | Live OpenStreetMap with WAQI stations. Click a number to open a station, click the map to check a spot |
| Precautions | Advice for the current level, plus a sensitive-groups note |
| Data and API | Live JSON, pipeline and system status |

## How the forecast works

1. Every station you open is saved and tracked. The backend stores one reading per hour in SQLite (`backend/airwatch.db`) and polls tracked stations every 30 minutes.
2. To avoid waiting a week, it also loads 14 days of **modelled** history from Open-Meteo the first time a station is tracked. The forecast page shows how many modelled hours were used. Set `BACKFILL_DAYS=0` to turn this off.
3. With at least 168 hourly records it trains both models in the background and scores them on recent hours they never saw, against a "same as now" guess. The page shows those errors honestly.
4. With fewer records it shows "More historical data is required". It never makes up a forecast.

## API

| Endpoint | Purpose |
|---|---|
| `GET /api/health` | Server, token and collector status |
| `GET /api/aqi?city=Delhi` | Current reading by city name or `@stationId` |
| `GET /api/location?lat=..&lon=..` | Current reading nearest a point |
| `GET /api/history?station=ID&hours=48` | Saved readings |
| `GET /api/forecast?station=ID[&refresh=true]` | 24-hour AI forecast, or why there is none |
| `GET /api/stations?bounds=lat1,lon1,lat2,lon2` | Stations in a map window |

Errors return `{"status":"error","code":"...","message":"..."}` with a matching HTTP status (400, 404, 502, 503). They never contain the token.

## Tests

```bash
cd backend && python -m unittest discover -s tests -t .     # 36 tests
cd frontend && node tests/chartMath.test.mjs                # chart and scale helpers
```

## Settings (`backend/.env`)

`WAQI_TOKEN` (required) · `FLASK_DEBUG` · `CORS_ORIGINS` · `AIRWATCH_DB` · `ENABLE_COLLECTOR` ·
`COLLECT_EVERY_MIN` · `BACKFILL_DAYS` · `MIN_RECORDS` · `RETRAIN_HOURS`

## Good to know

- **Scale.** WAQI reports the US EPA AQI, so categories are Good / Moderate / Unhealthy for Sensitive Groups / Unhealthy / Very Unhealthy / Hazardous. The Indian CPCB scale labels the same numbers differently.
- **Accuracy.** A week or two of history is small for an LSTM. Judge the forecast by the "How accurate is it?" table, and expect it to improve as readings accumulate.
- **Production.** Use one worker (`waitress-serve --port=5000 run:app` on Windows, `gunicorn -w 1 -b 127.0.0.1:5000 run:app` elsewhere) because the collector and model cache live in the process. Build the frontend with `npm run build`.
- **Data.** Real-time station data is supplied by WAQI (https://aqicn.org). Forecasts are statistical estimates, not official warnings.
