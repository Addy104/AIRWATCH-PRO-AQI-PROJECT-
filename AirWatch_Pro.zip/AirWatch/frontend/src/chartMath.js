// Pure chart helpers (no React) so they can be tested on their own.
import { BAND_EDGES } from "./lib/scale.js";

export const linear = (d0, d1, r0, r1) => (v) => (d1 === d0 ? (r0 + r1) / 2 : r0 + ((v - d0) / (d1 - d0)) * (r1 - r0));

export const linePath = (pts) => pts.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`).join(" ");
export const bandPath = (upper, lower) => `${linePath([...upper, ...[...lower].reverse()])} Z`;

export function yTicks(max) {
  const step = max <= 120 ? 20 : max <= 250 ? 50 : 100;
  const top = Math.max(step, Math.ceil(max / step) * step);
  const ticks = [];
  for (let v = 0; v <= top; v += step) ticks.push(v);
  return { ticks, top };
}

export function timeTicks(t0, t1, everyHours = 6) {
  const out = [];
  const d = new Date(t0);
  d.setMinutes(0, 0, 0);
  d.setHours(Math.ceil(d.getHours() / everyHours) * everyHours);
  for (let t = d.getTime(); t <= t1; ) {
    out.push(t);
    const n = new Date(t);
    n.setHours(n.getHours() + everyHours);
    t = n.getTime();
  }
  return out;
}

export function nearestIndex(xs, x) {
  let best = 0;
  for (let i = 1; i < xs.length; i++) if (Math.abs(xs[i] - x) < Math.abs(xs[best] - x)) best = i;
  return best;
}

const bandsFor = (y, top, m, W) =>
  BAND_EDGES.slice(0, -1)
    .map((from, i) => ({ i, from, to: BAND_EDGES[i + 1] }))
    .filter((b) => b.from < top)
    .map((b) => ({ ...b, x: m.l, w: W - m.l - m.r, y0: y(Math.min(b.to, top)), y1: y(b.from) }));

const DEFAULT_M = { l: 46, r: 14, t: 14, b: 34 };

/** Recorded readings. points: [{t (ms), v, modelled}] */
export function buildTrend(points, W, H, m = DEFAULT_M) {
  let t0 = points[0].t, t1 = points[points.length - 1].t;
  if (t1 - t0 < 3600e3) t1 = t0 + 3600e3;
  const { ticks, top } = yTicks(Math.max(...points.map((p) => p.v)));
  const x = linear(t0, t1, m.l, W - m.r);
  const y = linear(0, top, H - m.b, m.t);
  const span = t1 - t0;
  return {
    W, H, m, x, y, ticks, top,
    xs: points.map((p) => x(p.t)),
    line: linePath(points.map((p) => [x(p.t), y(p.v)])),
    dots: points.map((p) => ({ cx: x(p.t), cy: y(p.v), modelled: p.modelled })),
    bands: bandsFor(y, top, m, W),
    tt: timeTicks(t0, t1, span > 36 * 3600e3 ? 12 : 6).map((t) => ({ t, x: x(t) })),
  };
}

/** History plus 24 h forecast. api = /api/forecast response with status "ok". */
export function buildForecast(api, W, H, m = DEFAULT_M) {
  const hist = api.history.map((p) => ({ t: Date.parse(p.ts), v: p.aqi }));
  const fc = api.forecast.map((p) => ({ ...p, t: Date.parse(p.ts) }));
  const last = hist[hist.length - 1];
  const t0 = hist[0].t, t1 = fc[fc.length - 1].t;
  const all = [...hist.map((p) => p.v), ...fc.map((p) => p.high), ...fc.map((p) => p.rf), ...fc.map((p) => p.lstm ?? 0)];
  const { ticks, top } = yTicks(Math.max(...all));
  const x = linear(t0, t1, m.l, W - m.r);
  const y = linear(0, top, H - m.b, m.t);
  const join = (key) => [[x(last.t), y(last.v)], ...fc.filter((p) => p[key] != null).map((p) => [x(p.t), y(p[key])])];
  return {
    W, H, m, x, y, ticks, top,
    xs: [...hist.map((p) => x(p.t)), ...fc.map((p) => x(p.t))],
    rows: [...hist.map((p) => ({ t: p.t, actual: p.v })),
      ...fc.map((p) => ({ t: p.t, rf: p.rf, lstm: p.lstm, ensemble: p.ensemble, low: p.low, high: p.high }))],
    now: x(last.t),
    actual: linePath(hist.map((p) => [x(p.t), y(p.v)])),
    rf: linePath(join("rf")),
    lstm: fc.some((p) => p.lstm != null) ? linePath(join("lstm")) : null,
    ensemble: linePath(join("ensemble")),
    band: bandPath([[x(last.t), y(last.v)], ...fc.map((p) => [x(p.t), y(p.high)])],
      [[x(last.t), y(last.v)], ...fc.map((p) => [x(p.t), y(p.low)])]),
    bands: bandsFor(y, top, m, W),
    tt: timeTicks(t0, t1).map((t) => ({ t, x: x(t) })),
  };
}
