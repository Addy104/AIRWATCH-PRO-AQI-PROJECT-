import { useCallback, useEffect, useState } from "react";
import Sidebar, { VIEWS } from "./components/Sidebar";
import Header from "./components/Header";
import Notice from "./components/Notice";
import Overview from "./pages/Overview";
import Pollutants from "./pages/Pollutants";
import Forecast from "./pages/Forecast";
import MapPage from "./pages/MapPage";
import Precautions from "./pages/Precautions";
import DataPage from "./pages/DataPage";
import { useForecast, useStation } from "./hooks/useStation";
import { fmt } from "./lib/scale";

const readHash = () => {
  const h = window.location.hash.slice(1);
  return VIEWS[h] ? h : "overview";
};

export default function App() {
  const [view, setViewState] = useState(readHash);
  const [notice, setNotice] = useState("");
  const [locating, setLocating] = useState(false);
  const st = useStation();
  const forecast = useForecast(st.data?.station?.id);
  const { data } = st;

  const setView = useCallback((v) => { setViewState(v); window.history.replaceState(null, "", `#${v}`); }, []);
  useEffect(() => {
    const on = () => setViewState(readHash());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  useEffect(() => {
    document.title = data?.available ? `AQI ${fmt(data.aqi)} · ${data.station?.name} - AirWatch` : "AirWatch - Real-Time AQI";
  }, [data]);

  const locate = () => {
    if (!navigator.geolocation) { setNotice("Your browser does not support location."); return; }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => { setLocating(false); setNotice(""); st.selectGeo(pos.coords.latitude, pos.coords.longitude); setView("overview"); },
      (err) => { setLocating(false); setNotice(err.code === 1 ? "Location permission was not granted. Allow it in the address bar and try again." : "Could not get your location."); },
      { timeout: 15000 },
    );
  };

  if (st.loading && !data && !st.error) return <div className="app-loading">Loading AirWatch…</div>;

  return (
    <div className="shell">
      <Sidebar view={view} setView={setView} data={data} />
      <main className="main">
        <Header view={view} selected={st.selected} data={data} onCity={st.selectCity} onRefresh={st.refresh}
          onLocate={locate} locating={locating} updated={st.updated} error={st.error} loading={st.loading} />
        {notice && <Notice kind="warn" onClose={() => setNotice("")}>{notice}</Notice>}
        {st.error && <Notice title="Unable to get live data." action="Try again" onAction={st.refresh}>{st.error}{data ? " Showing the last reading." : ""}</Notice>}
        {!data ? (
          <div className="card"><p className="note">No data for this place yet.</p></div>
        ) : (
          <>
            {view === "overview" && <Overview data={data} history={st.history} forecast={forecast} setView={setView} />}
            {view === "pollutants" && <Pollutants data={data} />}
            {view === "forecast" && <Forecast data={data} forecast={forecast} />}
            {view === "map" && <MapPage data={data}
              onPickStation={(id) => st.selectCity(`@${id}`)}
              onPickPoint={(lat, lon) => st.selectGeo(lat, lon)} />}
            {view === "prec" && <Precautions data={data} />}
            {view === "data" && <DataPage data={data} history={st.history} updated={st.updated} error={st.error} />}
          </>
        )}
        <p className="foot">Real-time station data supplied by WAQI (US EPA AQI scale). Forecasts are statistical estimates, not official warnings.</p>
      </main>
    </div>
  );
}
