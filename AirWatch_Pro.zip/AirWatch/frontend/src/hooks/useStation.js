import { useCallback, useEffect, useRef, useState } from "react";
import { api } from "../lib/api";

const REFRESH_MS = 60_000;

/** Loads the selected station, refreshes it every minute and keeps recorded history for the trend. */
export function useStation() {
  const [sel, setSel] = useState({ type: "city", city: "Dehradun" });
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [updated, setUpdated] = useState(null);
  const [history, setHistory] = useState([]);
  const run = useRef(0);          // only the newest request may update the screen
  const abort = useRef(null);
  const dataKey = useRef("");     // which selection the data on screen belongs to

  const load = useCallback(async () => {
    const id = ++run.current;
    abort.current?.abort();
    const ctrl = (abort.current = new AbortController());
    try {
      const d = sel.type === "geo"
        ? await api("/location", { lat: sel.lat, lon: sel.lon }, { signal: ctrl.signal })
        : await api("/aqi", { city: sel.city }, { signal: ctrl.signal });
      if (id !== run.current) return;
      dataKey.current = JSON.stringify(sel);
      setData(d);
      setError("");
      setUpdated(new Date());
    } catch (e) {
      if (e.name === "AbortError" || id !== run.current) return;
      setError(e.message);
      if (dataKey.current !== JSON.stringify(sel)) setData(null);   // never show another station's reading as this one
    } finally {
      if (id === run.current) setLoading(false);
    }
  }, [sel]);

  useEffect(() => {                  // new selection: keep the old screen until the new reading arrives
    setLoading(true);
    setError("");
    load();
    const t = setInterval(load, REFRESH_MS);
    return () => { clearInterval(t); abort.current?.abort(); };
  }, [load]);

  const stationId = data?.station?.id;
  useEffect(() => {
    if (!stationId) { setHistory([]); return; }
    const ctrl = new AbortController();
    api("/history", { station: stationId, hours: 48 }, { signal: ctrl.signal })
      .then((r) => setHistory(r.points))
      .catch(() => {});
    return () => ctrl.abort();
  }, [stationId, updated]);

  return {
    data, history, error, loading, updated, refresh: load,
    selectCity: (city) => setSel({ type: "city", city }),
    selectGeo: (lat, lon) => setSel({ type: "geo", lat, lon }),
    selected: sel,
  };
}

/** Polls the AI forecast for a station; faster while models are training. */
export function useForecast(stationId) {
  const [state, setState] = useState({ data: null, error: "" });
  const load = useCallback(async (refresh = false, signal) => {
    if (!stationId) return;
    try {
      const d = await api("/forecast", { station: stationId, refresh: refresh ? "true" : undefined }, { signal });
      setState({ data: d, error: "" });
    } catch (e) {
      if (e.name !== "AbortError") setState((s) => ({ ...s, error: e.message }));
    }
  }, [stationId]);

  const busy = !state.data || state.data.status === "training" || state.data.refreshing;
  useEffect(() => { setState({ data: null, error: "" }); }, [stationId]);
  useEffect(() => {
    const ctrl = new AbortController();
    load(false, ctrl.signal);
    const t = setInterval(() => load(false, ctrl.signal), busy ? 4000 : 5 * 60_000);
    return () => { clearInterval(t); ctrl.abort(); };
  }, [load, busy]);

  return { ...state, run: () => load(true) };
}
