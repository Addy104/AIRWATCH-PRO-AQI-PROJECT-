import MapView from "../components/MapView";
import Pill from "../components/Pill";
import { fmt } from "../lib/scale";

export default function MapPage({ data, onPickStation, onPickPoint }) {
  const lat = data.station?.latitude, lon = data.station?.longitude;
  const center = lat != null && lon != null ? [lat, lon] : null;
  return (
    <section className="view">
      <div className="grid">
        <div className="card span8 mapcard">
          <div className="maptools">
            <div><h2 className="sec-title">Live station map</h2><p className="sec-sub">Zoom in to see stations. Click a number to open it, or click the map to check that spot.</p></div>
          </div>
          <MapView center={center} selectedId={data.station?.id} onPickStation={onPickStation} onPickPoint={onPickPoint} />
          {data.station?.url && <a className="station-link" href={data.station.url} target="_blank" rel="noreferrer">Open this station on aqicn.org</a>}
        </div>
        <div className="side-stack span4">
          <div className="card sel-card">
            <div className="label">Selected station</div>
            <div className="sec-title station-title">{data.station?.name}</div>
            <div className="big">{fmt(data.aqi)}</div>
            <Pill level={data.level} />
            <div className="kv map-kv">
              <div><span>Latitude</span><b>{fmt(lat, 5)}</b></div>
              <div><span>Longitude</span><b>{fmt(lon, 5)}</b></div>
              <div><span>Measured</span><b>{data.measured_at?.local || "—"}</b></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
