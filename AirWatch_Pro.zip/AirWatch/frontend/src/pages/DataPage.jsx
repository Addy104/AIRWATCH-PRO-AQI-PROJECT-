import { useEffect, useState } from "react";
import { api } from "../lib/api";

export default function DataPage({ data, history, updated, error }) {
  const [health, setHealth] = useState(null);
  useEffect(() => { api("/health").then(setHealth).catch(() => setHealth(null)); }, [updated]);
  const modelled = history.filter((p) => p.modelled).length;
  return (
    <section className="view">
      <div className="grid">
        <div className="card span12">
          <div className="sec-head"><div><h2 className="sec-title">System pipeline</h2><p className="sec-sub">How a reading gets from the sensor to the forecast</p></div></div>
          <div className="flow">
            <div><b>WAQI</b><p>Live station readings</p></div><span>→</span>
            <div><b>Flask API</b><p>Holds the WAQI token, checks input, caches</p></div><span>→</span>
            <div><b>History database</b><p>Hourly readings saved per station</p></div><span>→</span>
            <div><b>Random Forest + LSTM</b><p>24-hour forecast with a range</p></div><span>→</span>
            <div><b>React dashboard</b><p>Cards, charts, map</p></div>
          </div>
        </div>
        <div className="card span6">
          <div className="sec-head"><div><h2 className="sec-title">Live response</h2><p className="sec-sub">GET /api/aqi</p></div></div>
          <pre>{JSON.stringify(data, null, 2)}</pre>
        </div>
        <div className="card span6">
          <div className="sec-head"><div><h2 className="sec-title">Dashboard status</h2></div></div>
          <div className="kv">
            <div><span>API</span><b>{error ? "PROBLEM" : "CONNECTED"}</b></div>
            <div><span>WAQI token</span><b>{health ? (health.token_configured ? "CONFIGURED" : "MISSING") : "—"}</b></div>
            <div><span>History collector</span><b>{health ? (health.collector.running ? `RUNNING (every ${health.collector.every_min} min)` : "OFF") : "—"}</b></div>
            <div><span>Stations tracked</span><b>{health?.stations_tracked ?? "—"}</b></div>
            <div><span>Saved readings (48 h)</span><b>{history.length}{modelled ? ` (${modelled} modelled)` : ""}</b></div>
            <div><span>Last update</span><b>{updated?.toLocaleTimeString() || "—"}</b></div>
          </div>
          <p className="note" style={{ marginTop: 14 }}>Data supplied by <a className="station-link" href="https://aqicn.org/" target="_blank" rel="noreferrer">World Air Quality Index</a>.</p>
        </div>
      </div>
    </section>
  );
}
