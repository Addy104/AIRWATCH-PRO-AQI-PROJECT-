import Pill from "../components/Pill";
import { fmt } from "../lib/scale";

const STATUS = { ok: ["OK", 0], caution: ["Caution", 2], urgent: ["Urgent", 3] };

export default function Precautions({ data }) {
  const adv = data.advice;
  return (
    <section className="view">
      <div className="grid">
        <div className="card span12">
          <div className="phead">
            <div className="label">{data.station?.name}</div>
            <b>AQI {fmt(data.aqi)}</b>
            {data.available ? <Pill level={data.level} /> : <span className="pill nodata">No data</span>}
            <span className="note">{adv.summary}</span>
          </div>
        </div>
        {adv.actions.length > 0 && (
          <>
            <div className="card span8">
              <div className="sec-head"><div><h2 className="sec-title">What to do</h2><p className="sec-sub">For everyone, at this air quality</p></div></div>
              <ul className="prec">
                {adv.actions.map((a) => (
                  <li key={a.topic}>
                    <b>{a.topic}</b>
                    <Pill level={STATUS[a.status][1]}>{STATUS[a.status][0]}</Pill>
                    <p>{a.text}</p>
                  </li>
                ))}
              </ul>
            </div>
            <div className="card span4">
              <div className="sec-head"><div><h2 className="sec-title">Sensitive groups</h2><p className="sec-sub">Children, older adults, asthma, heart and lung conditions</p></div></div>
              <p className="lead">{adv.sensitive}</p>
            </div>
          </>
        )}
        <div className="card span12"><p className="note">General guidance based on the US EPA AQI scale. It is not medical advice. See a doctor if you have symptoms.</p></div>
      </div>
    </section>
  );
}
