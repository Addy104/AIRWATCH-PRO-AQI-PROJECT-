import ForecastPanel from "../components/ForecastPanel";

export default function Forecast({ forecast, data }) {
  return (
    <section className="view">
      <div className="grid">
        <ForecastPanel forecast={forecast} stationName={data.station?.name} />
        <div className="card span12">
          <div className="three">
            <div><b>Inputs</b><p>Recent AQI readings, temperature, humidity, wind and the time of day, saved hourly for this station.</p></div>
            <div><b>Models</b><p>A Random Forest and an LSTM neural network. The combined line weights each by how well it did on hours it had not seen.</p></div>
            <div><b>Output</b><p>Hourly AQI for the next 24 hours with a range. If there is not enough history, nothing is predicted.</p></div>
          </div>
        </div>
      </div>
    </section>
  );
}
