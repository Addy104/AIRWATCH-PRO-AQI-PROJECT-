import Hero from "../components/Hero";
import Weather from "../components/Weather";
import TrendChart from "../components/TrendChart";
import { POLLUTANTS, cssColor, fmt, levelName, levelOf } from "../lib/scale";

function Outlook({ data, forecast }) {
  const f = forecast?.data;
  const ok = f?.status === "ok";
  const six = ok ? f.forecast[5] : null;
  const peak = ok ? f.forecast.reduce((a, b) => (b.ensemble > a.ensemble ? b : a)) : null;
  const diff = ok && data.aqi != null ? six.ensemble - data.aqi : 0;
  const lvl = ok ? levelOf(six.ensemble) : data.level;
  const word = !ok ? levelName(data.level) : diff > 8 ? "Rising" : diff < -8 ? "Improving" : "Steady";
  return (
    <div className="card span4">
      <div className="label">AI outlook · next 24 h</div>
      <div className="trend" style={{ "--c": cssColor(lvl) }}>
        <div className="trend-icon">{!ok ? "•" : diff > 8 ? "↗" : diff < -8 ? "↘" : "→"}</div>
        <b>{word}</b>
      </div>
      {ok ? (
        <>
          <p className="lead">AQI is expected to be about {Math.round(six.ensemble)} in 6 hours (range {Math.round(six.low)} to {Math.round(six.high)}).</p>
          <div className="kv">
            <div><span>Peak</span><b>{Math.round(peak.ensemble)} at {new Date(peak.ts).toLocaleTimeString([], { hour: "numeric" })}</b></div>
            <div><span>Models</span><b>{f.metrics.lstm_mae != null ? "RF + LSTM" : "Random Forest"}</b></div>
            <div><span>Error vs "same as now"</span><b>{Math.round((1 - f.metrics.ensemble_mae / f.metrics.persistence_mae) * 100)}% lower</b></div>
          </div>
        </>
      ) : (
        <>
          <p className="lead">
            {f?.status === "insufficient_data" ? `The AI forecast needs more history (${f.available} of ${f.required} readings).`
              : f?.status === "training" || !f ? "The AI forecast is preparing." : "The AI forecast is not available right now."}
          </p>
          <div className="kv">
            <div><span>Current AQI</span><b>{fmt(data.aqi)}</b></div>
            <div><span>Provider</span><b>WAQI</b></div>
            <div><span>Measured</span><b>{data.measured_at?.local || "—"}</b></div>
          </div>
        </>
      )}
    </div>
  );
}

export default function Overview({ data, history, forecast, setView }) {
  return (
    <section className="view">
      <div className="grid">
        <Hero data={data} history={history} />
        <Outlook data={data} forecast={forecast} />
        <Weather data={data} />
        <div className="card span12">
          <div className="sec-head"><div><h2 className="sec-title">Pollutants at a glance</h2><p className="sec-sub">Select one to open the detailed page</p></div></div>
          <div className="strip">
            {POLLUTANTS.map((p) => {
              const x = data.pollutants[p.key];
              return (
                <button type="button" className="mini" key={p.key} onClick={() => setView("pollutants")} style={{ "--c": cssColor(x.level) }}>
                  <span className="mn">{p.label}</span><b>{fmt(x.value)}</b>
                  <span className="mu">AQI sub-index</span><span className="mc">{levelName(x.level)}</span>
                </button>
              );
            })}
          </div>
        </div>
        <div className="card span12">
          <div className="sec-head"><div><h2 className="sec-title">AQI trend</h2><p className="sec-sub">Last 48 hours of readings saved for this station</p></div></div>
          <TrendChart history={history} />
          <p className="fine">Filled dots are measured by WAQI. Hollow dots are modelled hours used to start the history.</p>
        </div>
      </div>
    </section>
  );
}
