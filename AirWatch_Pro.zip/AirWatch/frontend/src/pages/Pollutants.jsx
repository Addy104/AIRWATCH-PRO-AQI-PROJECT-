import Pill from "../components/Pill";
import { POLLUTANTS, cssColor, fmt, levelName } from "../lib/scale";

export default function Pollutants({ data }) {
  const dom = (data.dominant || "").toLowerCase();
  return (
    <section className="view">
      <div className="grid">
        <div className="span12">
          <div className="pgrid">
            {POLLUTANTS.map((p) => {
              const x = data.pollutants[p.key];
              return (
                <article className="card pc" key={p.key} style={{ "--c": cssColor(x.level) }}>
                  <div className="pc-top">
                    <div><div className="pc-name">{p.label}</div><div className="pc-desc">{p.desc}</div></div>
                    {x.value == null ? <span className="pill nodata">No data</span> : <Pill level={x.level} />}
                  </div>
                  <div className="pc-val"><b>{fmt(x.value)}</b><span>AQI sub-index{dom === p.key ? " · main pollutant" : ""}</span></div>
                  <div className="meter" role="img" aria-label={`${p.label} sub-index ${fmt(x.value)} of 500`}>
                    <i style={{ width: `${x.value == null ? 0 : Math.min(100, Math.max(2, x.value / 5))}%` }} />
                  </div>
                </article>
              );
            })}
          </div>
        </div>
        <div className="card span12">
          <div className="sec-head"><div><h2 className="sec-title">What is driving the AQI</h2>
            <p className="sec-sub">The highest sub-index sets the overall AQI. WAQI reports each pollutant on the same 0 to 500 scale.</p></div></div>
          {POLLUTANTS.map((p) => {
            const x = data.pollutants[p.key];
            return (
              <div className="srow" key={p.key}>
                <div className="n">{p.label}</div>
                <div className="track" style={{ "--c": cssColor(x.level) }}>
                  <i style={{ width: `${x.value == null ? 0 : Math.min(100, Math.max(1, x.value / 5))}%` }} />
                  {[20, 40, 60, 80].map((l) => <u key={l} style={{ left: `${l}%` }} />)}
                </div>
                <div className="v">{fmt(x.value)}<small>{dom === p.key ? "Dominant" : levelName(x.level)}</small></div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
