export default function Notice({ kind = "error", title, children, action, onAction, onClose }) {
  return (
    <div className={`notice ${kind}`} role={kind === "error" ? "alert" : "status"}>
      <div>{title && <b>{title}</b>} <span>{children}</span></div>
      <div className="notice-actions">
        {action && <button type="button" className="action" onClick={onAction}>{action}</button>}
        {onClose && <button type="button" className="action" onClick={onClose} aria-label="Dismiss">Dismiss</button>}
      </div>
    </div>
  );
}
