import { cssColor, levelName } from "../lib/scale";

export default function Pill({ level, children }) {
  return <span className="pill" style={{ "--c": cssColor(level) }}>{children ?? levelName(level)}</span>;
}
