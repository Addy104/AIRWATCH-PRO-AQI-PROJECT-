import { VIEWS } from "./Sidebar";
import { CITIES } from "../lib/scale";

export default function Header({ view, selected, data, onCity, onRefresh, onLocate, updated, error, locating, loading }) {
  const inList = selected.type === "city" && CITIES.includes(selected.city);
  return (
    <header className="head">
      <div><h1>{VIEWS[view][0]}</h1><p>{VIEWS[view][1]}</p></div>
      <div className="controls">
        <span className="demo">WAQI live</span>
        <label className="sel" htmlFor="station-select">Station
          <select id="station-select" value={inList ? selected.city : "__custom"} onChange={(e) => onCity(e.target.value)}>
            {!inList && <option value="__custom" disabled>{data?.station?.name || "Custom location"}</option>}
            {CITIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
        </label>
        <button type="button" className="action" onClick={onLocate} disabled={locating}>
          {locating ? "Locating..." : "My location"}
        </button>
        <button type="button" className="action" onClick={onRefresh}>Refresh</button>
        <span className="live" role="status">
          <i className={error ? "bad" : ""} />
          <span className={error ? "err" : ""}>
            {error ? "Connection problem" : loading ? "Loading..." : updated ? `Updated ${updated.toLocaleTimeString()}` : "Connecting..."}
          </span>
        </span>
      </div>
    </header>
  );
}
