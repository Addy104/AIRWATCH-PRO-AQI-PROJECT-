import { useMemo, useRef, useState } from "react";
import { buildForecast, nearestIndex } from "../chartMath";
import { fmt, levelName, levelOf } from "../lib/scale";

const W = 920, H = 380;
const SERIES = [
  { key: "actual", label: "Measured", cls: "s-actual" },
  { key: "rf", label: "Random Forest", cls: "s-rf" },
  { key: "lstm", label: "LSTM", cls: "s-lstm" },
  { key: "ensemble", label: "Combined forecast", cls: "s-ens" },
];
const when = (t) => new Date(t).toLocaleString([], { weekday: "short", hour: "numeric" });
const tick = (t) => { const d = new Date(t); return d.getHours() === 0 ? d.toLocaleDateString([], { month: "short", day: "numeric" }) : d.toLocaleTimeString([], { hour: "numeric" }); };
const MODEL = { rf: "Random Forest", lstm: "LSTM" };

export default function ForecastPanel({ forecast, stationName }) {
  const { data, error, run } = forecast;
  const [hidden, setHidden] = useState({});
  const [hover, setHover] = useState(null);
  const svg = useRef(null);
  const chart = useMemo(() => (data?.status === "ok" ? buildForecast(data, W, H) : null), [data]);

  const head = (
    <header className="fc-head">
      <div>
        <h2 className="sec-title big-title">AI-powered AQI forecast</h2>
        <p className="sec-sub">Random Forest + LSTM trained on timestamped history for {stationName || "this station"}</p>
      </div>
      <button type="button" className="action" onClick={run}>Run prediction</button>
    </header>
  );
  const shell = (body) => <section className="card span12 fc">{head}{body}</section>;

  if (!data) return shell(<p className="note">{error || "Loading forecast..."}</p>);
  if (data.status === "training") return shell(<p className="note">Training the models on the latest history. This takes under a minute.</p>);
  if (data.status === "error") return shell(<p className="note">The forecast failed: {data.detail}</p>);
  if (data.status === "insufficient_data") {
    const pct = Math.min(100, (data.available / data.required) * 100);
    return shell(
      <div className="panel">
        <span className="label">Historical data requirement</span>
        <h3>More historical data is required</h3>
        <p>AirWatch will not invent a prediction when there is not enough history.</p>
        <div className="row"><span>Available records</span><b>{data.available} / {data.required}</b></div>
        <div className="progress" role="progressbar" aria-valuenow={data.available} aria-valuemin={0} aria-valuemax={data.required}><i style={{ width: `${pct}%` }} /></div>
        {data.detail && <p className="note">{data.detail}</p>}
        <p className="note">Readings are saved automatically while the backend runs. Every station you open is tracked.</p>
      </div>
    );
  }

  const mt = data.metrics;
  const gain = (m) => (m == null ? "—" : `${Math.round((1 - m / mt.persistence_mae) * 100)}% better`);
  const peak = data.forecast.reduce((a, b) => (b.ensemble > a.ensemble ? b : a));
  const end = data.forecast[data.forecast.length - 1];
  const modelled = data.sources?.["open-meteo"] || 0;
  const row = hover != null ? chart.rows[hover] : null;
  const onMove = (e) => {
    const r = svg.current.getBoundingClientRect();
    setHover(nearestIndex(chart.xs, ((e.clientX - r.left) / r.width) * W));
  };

  return shell(<>
    <div className="kpis">
      <div><span>Peak in next 24 h</span><b>{Math.round(peak.ensemble)}</b><small>{levelName(levelOf(peak.ensemble))} around {when(Date.parse(peak.ts))}</small></div>
      <div><span>In 24 hours</span><b>{Math.round(end.ensemble)}</b><small>Range {Math.round(end.low)} to {Math.round(end.high)}</small></div>
      <div><span>Trained on</span><b>{data.available}</b><small>hourly records{modelled ? `, ${modelled} modelled` : ""}</small></div>
    </div>

    <div className="legend">
      {SERIES.filter((s) => s.key !== "lstm" || chart.lstm).map((s) => (
        <button key={s.key} type="button" className={`chip-btn ${s.cls}`} aria-pressed={!hidden[s.key]}
          onClick={() => setHidden((h) => ({ ...h, [s.key]: !h[s.key] }))}><i />{s.label}</button>
      ))}
    </div>

    <div className="chartwrap fc-chart">
      <svg ref={svg} viewBox={`0 0 ${W} ${H}`} role="img" aria-label="AQI history and 24 hour forecast" onMouseMove={onMove} onMouseLeave={() => setHover(null)}>
        {chart.bands.map((b) => <rect key={b.i} x={b.x} y={b.y0} width={b.w} height={b.y1 - b.y0} style={{ fill: `var(--c${b.i})` }} opacity="0.09" />)}
        {chart.ticks.map((v) => (
          <g key={v}>
            <line className="gl" x1={chart.m.l} x2={W - chart.m.r} y1={chart.y(v)} y2={chart.y(v)} />
            <text className="ax" x={chart.m.l - 8} y={chart.y(v) + 4} textAnchor="end">{v}</text>
          </g>
        ))}
        {chart.tt.map((t) => <text key={t.t} className="ax" x={t.x} y={H - 12} textAnchor="middle">{tick(t.t)}</text>)}
        <line className="now" x1={chart.now} x2={chart.now} y1={chart.m.t} y2={H - chart.m.b} />
        <text className="ax" x={chart.now + 6} y={chart.m.t + 10}>Now</text>
        {!hidden.ensemble && <path className="band" d={chart.band} />}
        {!hidden.rf && <path className="fline s-rf" d={chart.rf} />}
        {!hidden.lstm && chart.lstm && <path className="fline s-lstm" d={chart.lstm} />}
        {!hidden.ensemble && <path className="fline s-ens thick" d={chart.ensemble} />}
        {!hidden.actual && <path className="fline s-actual thick" d={chart.actual} />}
        {hover != null && <line className="guide" x1={chart.xs[hover]} x2={chart.xs[hover]} y1={chart.m.t} y2={H - chart.m.b} />}
      </svg>
      {row && (
        <div className="tip" style={{ left: `${(chart.xs[hover] / W) * 100}%` }}>
          <b>{when(row.t)}</b>
          {row.actual != null
            ? <div><i className="sw s-actual" />Measured <b>{Math.round(row.actual)}</b></div>
            : <>
                <div><i className="sw s-ens" />Combined <b>{Math.round(row.ensemble)}</b> <small>({Math.round(row.low)} to {Math.round(row.high)})</small></div>
                <div><i className="sw s-rf" />Random Forest <b>{Math.round(row.rf)}</b></div>
                {row.lstm != null && <div><i className="sw s-lstm" />LSTM <b>{Math.round(row.lstm)}</b></div>}
              </>}
        </div>
      )}
    </div>
    <p className="note">The shaded band is an approximate 80% range based on each model's error on hours it had not seen. Background colours are AQI categories.</p>

    <div className="metrics">
      <h3 className="sec-title">How accurate is it?</h3>
      <div className="tw">
        <table>
          <thead><tr><th>Model</th><th>Average error</th><th>Compared with "same as now"</th></tr></thead>
          <tbody>
            <tr><td>Same as now (baseline)</td><td>{fmt(mt.persistence_mae, 1)} AQI</td><td>—</td></tr>
            <tr><td>Random Forest</td><td>{fmt(mt.rf_mae, 1)} AQI</td><td>{gain(mt.rf_mae)}</td></tr>
            {mt.lstm_mae != null && <tr><td>LSTM</td><td>{fmt(mt.lstm_mae, 1)} AQI</td><td>{gain(mt.lstm_mae)}</td></tr>}
            <tr><td>Combined</td><td>{fmt(mt.ensemble_mae, 1)} AQI</td><td>{gain(mt.ensemble_mae)}</td></tr>
          </tbody>
        </table>
      </div>
      <p className="note">
        Errors are measured on the latest {mt.validation_hours} hours, which were held back from training. Weights in the combined
        forecast: {Object.entries(mt.weights).map(([k, v]) => `${MODEL[k]} ${Math.round(v * 100)}%`).join(", ")}.
        {data.note ? ` ${data.note}` : ""}{data.stale_hours > 3 ? ` The latest reading is ${Math.round(data.stale_hours)} hours old.` : ""}
      </p>
    </div>
  </>);
}
