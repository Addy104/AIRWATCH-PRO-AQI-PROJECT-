import { useMemo, useState } from "react";
import { buildTrend, nearestIndex } from "../chartMath";
import { fmt, levelOf } from "../lib/scale";
import Pill from "./Pill";

const W = 900, H = 300;
const when = (t) => new Date(t).toLocaleString([], { weekday: "short", hour: "numeric", minute: "2-digit" });
const tick = (t) => { const d = new Date(t); return d.getHours() === 0 ? d.toLocaleDateString([], { month: "short", day: "numeric" }) : d.toLocaleTimeString([], { hour: "numeric" }); };

/** Recorded AQI for the station. Filled dots are measured, hollow dots are modelled bootstrap hours. */
export default function TrendChart({ history }) {
  const [hover, setHover] = useState(null);
  const pts = useMemo(() => history.map((p) => ({ t: p.ts * 1000, v: p.aqi, modelled: p.modelled })), [history]);
  const c = useMemo(() => (pts.length >= 2 ? buildTrend(pts, W, H) : null), [pts]);

  if (!c) {
    return <p className="note">Only {pts.length} reading{pts.length === 1 ? "" : "s"} recorded for this station so far. The chart appears after the next hourly reading is saved.</p>;
  }
  const onMove = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    setHover(nearestIndex(c.xs, ((e.clientX - r.left) / r.width) * W));
  };
  const p = hover != null ? pts[hover] : null;
  return (
    <div className="chartwrap">
      <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="AQI over the last 48 hours" onMouseMove={onMove} onMouseLeave={() => setHover(null)}>
        {c.bands.map((b) => <rect key={b.i} x={b.x} y={b.y0} width={b.w} height={b.y1 - b.y0} style={{ fill: `var(--c${b.i})` }} opacity="0.09" />)}
        {c.ticks.map((v) => (
          <g key={v}>
            <line className="gl" x1={c.m.l} x2={W - c.m.r} y1={c.y(v)} y2={c.y(v)} />
            <text className="ax" x={c.m.l - 8} y={c.y(v) + 4} textAnchor="end">{v}</text>
          </g>
        ))}
        {c.tt.map((t) => <text key={t.t} className="ax" x={t.x} y={H - 12} textAnchor="middle">{tick(t.t)}</text>)}
        <path className="tline" d={c.line} />
        {c.dots.map((d, i) => (
          <circle key={i} cx={d.cx} cy={d.cy} r={pts.length > 60 ? 2.2 : 3.5} className={d.modelled ? "dot hollow" : "dot"} />
        ))}
        {hover != null && <line className="guide" x1={c.xs[hover]} x2={c.xs[hover]} y1={c.m.t} y2={H - c.m.b} />}
      </svg>
      {p && (
        <div className="tip" style={{ left: `${(c.xs[hover] / W) * 100}%` }}>
          <b>{when(p.t)}</b>
          <div>AQI <b>{fmt(p.v)}</b> <Pill level={levelOf(p.v)} /></div>
          <small>{p.modelled ? "Modelled (Open-Meteo)" : "Measured (WAQI)"}</small>
        </div>
      )}
    </div>
  );
}
