import Icon from "./Icon";
import Pill from "./Pill";
import { fmt } from "../lib/scale";

export const VIEWS = {
  overview: ["Overview", "Live conditions for the selected station"],
  pollutants: ["Pollutants", "Current pollutant levels and what is driving the AQI"],
  forecast: ["AI forecast", "Next 24 hours from Random Forest and LSTM models"],
  map: ["Map", "Live stations around the world"],
  prec: ["Precautions", "Health guidance for the current air quality"],
  data: ["Data and API", "Live API response and system status"],
};

export default function Sidebar({ view, setView, data }) {
  const Item = ({ k }) => (
    <button type="button" onClick={() => setView(k)} aria-current={view === k ? "page" : undefined}>
      <Icon type={k} />{VIEWS[k][0]}
    </button>
  );
  return (
    <aside className="side">
      <div className="brand">
        <div className="logo" aria-hidden="true">◎</div>
        <div><b>AirWatch</b><span>AQI monitor with AI forecast</span></div>
      </div>
      <div>
        <p className="nav-label">Dashboard</p>
        <nav className="nav" aria-label="Dashboard pages">
          {["overview", "pollutants", "forecast", "map", "prec"].map((k) => <Item key={k} k={k} />)}
        </nav>
      </div>
      <div>
        <p className="nav-label">Project</p>
        <nav className="nav" aria-label="Project"><Item k="data" /></nav>
      </div>
      <div className="side-foot">
        <div className="chip">
          <span className="st">Selected station</span>
          <b className="nm">{data?.station?.name || "Loading..."}</b>
          <div className="chip-row">
            <strong>{data ? fmt(data.aqi) : "—"}</strong>
            {data && <Pill level={data.level} />}
          </div>
        </div>
      </div>
    </aside>
  );
}
