import { useEffect, useRef, useState } from "react";
import L from "leaflet";
import { api } from "../lib/api";
import { COLORS } from "../lib/scale";

const MIN_ZOOM_FOR_STATIONS = 7;

/** OpenStreetMap with live WAQI stations. Click a number to open that station, click empty map to check that spot. */
export default function MapView({ center, selectedId, onPickStation, onPickPoint }) {
  const el = useRef(null);
  const map = useRef(null);
  const layer = useRef(null);
  const cb = useRef({});
  const [stations, setStations] = useState([]);
  const [hint, setHint] = useState("");
  cb.current = { onPickStation, onPickPoint };

  // create the map once
  useEffect(() => {
    const m = L.map(el.current, { zoomControl: true }).setView(center || [20.6, 78.9], center ? 10 : 5);
    L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 18, attribution: "&copy; OpenStreetMap contributors",
    }).addTo(m);
    layer.current = L.layerGroup().addTo(m);
    map.current = m;

    let timer, ctrl;
    const refresh = () => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        if (m.getZoom() < MIN_ZOOM_FOR_STATIONS) {
          setStations([]);
          setHint("Zoom in to see live stations.");
          return;
        }
        const b = m.getBounds();
        ctrl?.abort();
        ctrl = new AbortController();
        try {
          const r = await api("/stations", { bounds: `${b.getSouth()},${b.getWest()},${b.getNorth()},${b.getEast()}` }, { signal: ctrl.signal });
          setStations(r.stations);
          setHint(r.stations.length ? "" : "No live stations in this view.");
        } catch (e) {
          if (e.name !== "AbortError") setHint(e.message);
        }
      }, 500);
    };
    m.on("moveend", refresh);
    m.on("click", (e) => cb.current.onPickPoint?.(e.latlng.lat, e.latlng.lng));
    setTimeout(() => { m.invalidateSize(); refresh(); }, 0);
    return () => { clearTimeout(timer); ctrl?.abort(); m.remove(); map.current = null; };
  }, []); 

  // follow the selected station
  useEffect(() => {
    if (map.current && center) map.current.flyTo(center, Math.max(map.current.getZoom(), 10), { duration: 0.8 });
  }, [center?.[0], center?.[1]]); 

  // draw station markers
  useEffect(() => {
    if (!layer.current) return;
    layer.current.clearLayers();
    stations.forEach((s) => {
      const color = COLORS[s.level ?? 0];
      const text = (s.level ?? 0) >= 4 ? "#fff" : "#0a1419";
      const selected = String(s.id) === String(selectedId);
      const icon = L.divIcon({
        className: "aq-pin-wrap",
        html: `<span class="aq-pin${selected ? " sel" : ""}" style="background:${color};color:${text}">${Math.round(s.aqi)}</span>`,
        iconSize: [38, 24], iconAnchor: [19, 12],
      });
      const marker = L.marker([s.lat, s.lon], { icon, keyboard: false, zIndexOffset: selected ? 1000 : 0 });
      marker.bindTooltip(s.name || "Station", { direction: "top", offset: [0, -10] });
      marker.on("click", (e) => { L.DomEvent.stopPropagation(e); cb.current.onPickStation?.(s.id, s.name); });
      marker.addTo(layer.current);
    });
  }, [stations, selectedId]);

  return (
    <div className="mapbox">
      <div ref={el} className="leaflet-host" role="application" aria-label="Map of live air quality stations" />
      {hint && <div className="map-hint">{hint}</div>}
    </div>
  );
}
