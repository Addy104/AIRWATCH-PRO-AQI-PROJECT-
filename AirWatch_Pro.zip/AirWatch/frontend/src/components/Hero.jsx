import Pill from "./Pill";
import { BAND_EDGES, cssColor, fmt } from "../lib/scale";

export default function Hero({ data, history }) {
  const a = data.available ? data.aqi : null;
  const day = history.filter((p) => p.ts * 1000 > Date.now() - 24 * 3600e3 && !p.modelled).map((p) => p.aqi);
  const stat = (f) => (day.length ? Math.round(f(day)) : "—");
  const dominant = data.dominant ? data.dominant.replace("pm25", "PM₂.₅").replace("pm10", "PM₁₀").toUpperCase() : "—";
  return (
    <div className="card hero span8" style={{ "--c": cssColor(data.level) }}>
      <div className="label">Air Quality Index · {data.station?.name || "Station"}</div>
      <div className="hero-main">
        <div className="aqi-num">{a == null ? "—" : Math.round(a)}</div>
        <div className="hero-text">
          {a == null ? <Pill level={null}>No current reading</Pill> : <Pill level={data.level} />}
          <p>{data.advice?.summary}</p>
        </div>
      </div>
      <div className="scale" aria-hidden="true">
        <div className="bar">
          {BAND_EDGES.slice(0, -1).map((from, i) => (
            <div key={from} style={{ "--c": `var(--c${i})`, flex: BAND_EDGES[i + 1] - from }} />
          ))}
        </div>
        {a != null && <div className="marker" style={{ left: `${Math.min(99.4, Math.max(0.6, a / 5))}%` }} />}
      </div>
      <div className="ticks" aria-hidden="true">
        {BAND_EDGES.map((v) => <span key={v} style={{ left: `${v / 5}%` }}>{v}</span>)}
      </div>
      <div className="stats">
        <div className="stat"><b>{dominant}</b><span>Main pollutant</span></div>
        <div className="stat"><b>{stat((v) => Math.min(...v))}</b><span>24 h low</span></div>
        <div className="stat"><b>{stat((v) => Math.max(...v))}</b><span>24 h high</span></div>
        <div className="stat"><b>{stat((v) => v.reduce((x, y) => x + y, 0) / v.length)}</b><span>24 h average</span></div>
      </div>
      {data.stale && <p className="fine warn">WAQI is not responding, so this is the last reading received.</p>}
    </div>
  );
}
