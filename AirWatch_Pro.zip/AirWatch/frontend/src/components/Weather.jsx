import Icon from "./Icon";
import { fmt } from "../lib/scale";

export default function Weather({ data }) {
  const w = data.weather || {};
  const rows = [
    ["temp", fmt(w.temperature, 1), "°C", "Temperature"],
    ["humidity", fmt(w.humidity), "%", "Humidity"],
    ["wind", fmt(w.wind_kmh, 1), "km/h", "Wind"],
    ["pressure", fmt(w.pressure), "hPa", "Pressure"],
  ];
  return (
    <div className="card span12">
      <div className="wgrid">
        {rows.map(([icon, v, u, label]) => (
          <div className="wtile" key={label}>
            <Icon type={icon} size={38} />
            <div><b>{v}<small>{v === "—" ? "" : u}</small></b><span>{label}</span></div>
          </div>
        ))}
      </div>
    </div>
  );
}
