import { buildTrend, buildForecast, yTicks, nearestIndex } from "../src/chartMath.js";
import { levelOf, levelName, fmt } from "../src/lib/scale.js";
const eq = (a, b, m) => { if (JSON.stringify(a) !== JSON.stringify(b)) { console.log("FAIL", m, a, b); process.exitCode = 1; } else console.log("ok  ", m); };
eq([levelOf(0), levelOf(50), levelOf(51), levelOf(164), levelOf(301), levelOf(999), levelOf(null), levelOf("-"), levelOf(undefined)], [0, 0, 1, 3, 5, 5, null, null, null], "levelOf incl. offline");
eq(levelName(levelOf(164)), "Unhealthy", "164 is Unhealthy on the US scale");
eq([fmt(null), fmt("-"), fmt(12.345, 1), fmt(0)], ["—", "—", "12.3", "0"], "fmt");
eq(yTicks(95).top, 100, "yTicks small"); eq(yTicks(420).ticks, [0,100,200,300,400,500], "yTicks large");
const now = Date.UTC(2026, 9, 21, 8);
const pts = Array.from({ length: 48 }, (_, i) => ({ t: now - (47 - i) * 36e5, v: 90 + 40 * Math.sin(i / 7), modelled: i < 10 }));
const tr = buildTrend(pts, 900, 300);
eq(tr.xs.every((x) => x >= 46 && x <= 886), true, "trend points inside plot");
eq(tr.dots.filter((d) => d.modelled).length, 10, "modelled dots flagged");
eq(buildTrend([{ t: now, v: 80 }, { t: now + 1000, v: 85 }], 900, 300).xs.every(Number.isFinite), true, "two points in one hour still scale");
const api = {
  history: pts.map((p) => ({ ts: new Date(p.t).toISOString(), aqi: p.v })),
  forecast: Array.from({ length: 24 }, (_, i) => ({ ts: new Date(now + (i + 1) * 36e5).toISOString(), rf: 100 + i, lstm: 98 + i, ensemble: 99 + i, low: 85 + i, high: 120 + 2 * i })),
};
const fc = buildForecast(api, 920, 380);
eq([fc.xs.length, fc.rows.length, fc.band.endsWith("Z"), !!fc.lstm], [72, 72, true, true], "forecast series built");
eq(fc.xs.every((x) => x >= 46 && x <= 906), true, "forecast points inside plot");
eq(buildForecast({ ...api, forecast: api.forecast.map((p) => ({ ...p, lstm: null })) }, 920, 380).lstm, null, "no LSTM -> no LSTM line");
eq(nearestIndex([10, 20, 30], 26), 2, "nearestIndex");
eq(fc.bands.map((b) => b.i), [0, 1, 2, 3], "bands only up to axis top (0-200)");
