import time
import unittest
from unittest import mock

import requests

from app import waqi
from app.errors import BadRequest, NotConfigured, NotFound, UpstreamUnavailable
from app.config import settings
from tests.base import DbTestCase, Fake, feed


class WaqiClientTests(DbTestCase):
    def test_token_is_sent_to_waqi(self):
        with mock.patch.object(waqi._session, "get", return_value=Fake(feed())) as g:
            waqi.feed_city("Dehradun")
        self.assertEqual(g.call_args.kwargs["params"]["token"], "SECRET123")

    def test_network_error_never_exposes_token(self):
        boom = requests.ConnectionError("failed for url https://api.waqi.info/feed/x/?token=SECRET123")
        with mock.patch.object(waqi._session, "get", side_effect=boom):
            with self.assertRaises(UpstreamUnavailable) as cm:
                waqi.feed_city("Delhi")
        self.assertNotIn("SECRET123", cm.exception.message)
        self.assertNotIn("SECRET123", repr(cm.exception.__cause__))

    def test_http_error_never_exposes_token(self):
        with mock.patch.object(waqi._session, "get", return_value=Fake(None, 403)):
            with self.assertRaises(UpstreamUnavailable) as cm:
                waqi.feed_city("Delhi")
        self.assertNotIn("SECRET123", cm.exception.message)

    def test_unknown_station_is_404_and_bad_key_is_503(self):
        with mock.patch.object(waqi._session, "get", return_value=Fake({"status": "error", "data": "Unknown station"})):
            with self.assertRaises(NotFound):
                waqi.feed_city("zzzz")
        waqi.clear_cache()
        with mock.patch.object(waqi._session, "get", return_value=Fake({"status": "error", "data": "Invalid key"})):
            with self.assertRaises(NotConfigured):
                waqi.feed_city("Delhi")

    def test_missing_token(self):
        settings.WAQI_TOKEN = ""
        with self.assertRaises(NotConfigured):
            waqi.feed_city("Delhi")

    def test_city_is_quoted_in_the_path(self):
        with mock.patch.object(waqi._session, "get", return_value=Fake(feed())) as g:
            waqi.feed_city("a/../b c")
        url = g.call_args.args[0]
        self.assertTrue(url.endswith("/feed/a%2F..%2Fb%20c/"), url)

    def test_bad_city_rejected(self):
        for bad in ("", "   ", "x" * 81):
            with self.assertRaises(BadRequest):
                waqi.feed_city(bad)

    def test_cache_and_stale_on_error(self):
        with mock.patch.object(waqi._session, "get", return_value=Fake(feed(aqi=70))) as g:
            waqi.feed_city("Delhi"); waqi.feed_city("Delhi")
            self.assertEqual(g.call_count, 1)                       # second call served from cache
        key = next(iter(waqi._cache))
        waqi._cache[key] = (time.time() - 120, waqi._cache[key][1])  # expire the fresh window
        with mock.patch.object(waqi._session, "get", side_effect=requests.ConnectionError("down")):
            data, stale = waqi.feed_city("Delhi")
        self.assertTrue(stale)
        self.assertEqual(data["aqi"], 70)


if __name__ == "__main__":
    unittest.main()
