import os
import tempfile
import unittest

from app import waqi
from app.config import settings


class Fake:
    """Stands in for a requests.Response."""
    def __init__(self, body=None, status=200):
        self._b, self.status_code = body, status

    def json(self):
        if self._b is None:
            raise ValueError("no json")
        return self._b


def feed(aqi=85, idx=1234, name="Test Station, Dehradun", **extra):
    d = {"aqi": aqi, "idx": idx, "dominentpol": "pm25",
         "city": {"name": name, "geo": [30.32, 78.03], "url": "https://aqicn.org/city/x"},
         "iaqi": {"pm25": {"v": 85}, "pm10": {"v": 60}, "no2": {"v": 12}, "o3": {"v": 30}, "so2": {"v": 3},
                  "co": {"v": 4.5}, "t": {"v": 26.5}, "h": {"v": 55}, "p": {"v": 1011}, "w": {"v": 2.0}},
         "time": {"s": "2026-10-21 12:00:00", "iso": "2026-10-21T12:00:00+05:30", "v": 1792564200}}
    d.update(extra)
    return {"status": "ok", "data": d}


class DbTestCase(unittest.TestCase):
    """Each test gets a fresh database, a known token and an empty WAQI cache."""
    def setUp(self):
        self._tmp = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self._tmp.close()
        self._old = (settings.DB_PATH, settings.WAQI_TOKEN)
        settings.DB_PATH, settings.WAQI_TOKEN = self._tmp.name, "SECRET123"
        waqi.clear_cache()

    def tearDown(self):
        settings.DB_PATH, settings.WAQI_TOKEN = self._old
        os.unlink(self._tmp.name)
        waqi.clear_cache()
