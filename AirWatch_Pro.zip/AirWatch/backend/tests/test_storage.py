import unittest

from app import storage
from tests.base import DbTestCase


class StorageTests(DbTestCase):
    def test_rows_are_bucketed_by_hour(self):
        storage.save_rows("1", [{"ts": 3600 * 10 + 59, "aqi": 80, "source": "waqi"}])
        storage.save_rows("1", [{"ts": 3600 * 10 + 5, "aqi": 90, "source": "waqi"}])
        df = storage.read("1", days=100000)
        self.assertEqual(len(df), 1)
        self.assertEqual(df["aqi"].iloc[0], 90)

    def test_measured_beats_modelled_but_not_the_reverse(self):
        storage.save_rows("1", [{"ts": 7200, "aqi": 100, "source": "open-meteo"}])
        storage.save_rows("1", [{"ts": 7200, "aqi": 120, "source": "waqi"}])
        storage.save_rows("1", [{"ts": 7200, "aqi": 55, "source": "open-meteo"}])
        df = storage.read("1", days=100000)
        self.assertEqual((df["aqi"].iloc[0], df["source"].iloc[0]), (120, "waqi"))

    def test_rows_without_aqi_are_ignored(self):
        self.assertEqual(storage.save_rows("1", [{"ts": 3600, "aqi": None, "source": "waqi"}]), 0)

    def test_counts_by_source(self):
        storage.save_rows("1", [{"ts": 3600, "aqi": 1, "source": "waqi"}, {"ts": 7200, "aqi": 2, "source": "open-meteo"}])
        self.assertEqual(storage.counts("1"), {"waqi": 1, "open-meteo": 1})

    def test_stations(self):
        self.assertTrue(storage.upsert_station("9", "A", 1.0, 2.0))
        self.assertFalse(storage.upsert_station("9", "A2", None, None))
        st = storage.get_station("9")
        self.assertEqual((st["name"], st["lat"]), ("A2", 1.0))     # name updates, coordinates are kept


if __name__ == "__main__":
    unittest.main()
