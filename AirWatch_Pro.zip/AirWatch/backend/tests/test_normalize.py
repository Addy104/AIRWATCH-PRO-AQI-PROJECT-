import unittest

from app import normalize, scale
from tests.base import feed


class NormalizeTests(unittest.TestCase):
    def test_levels_follow_us_scale(self):
        self.assertEqual([scale.level_of(v) for v in (0, 50, 51, 100, 101, 150, 151, 200, 201, 300, 301, 500)],
                         [0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5])
        self.assertEqual(scale.name_of(scale.level_of(164)), "Unhealthy")   # was "Moderate" in the old app

    def test_offline_station_is_not_zero(self):
        out = normalize.format_feed(feed(aqi="-")["data"])
        self.assertFalse(out["available"])
        self.assertIsNone(out["aqi"])
        self.assertIsNone(out["level"])
        self.assertIn("No current reading", out["advice"]["summary"])

    def test_missing_pollutant_has_no_level(self):
        d = feed()["data"]
        del d["iaqi"]["so2"]
        out = normalize.format_feed(d)
        self.assertIsNone(out["pollutants"]["so2"]["value"])
        self.assertIsNone(out["pollutants"]["so2"]["level"])

    def test_wind_is_converted_from_ms_to_kmh(self):
        self.assertEqual(normalize.format_feed(feed()["data"])["weather"]["wind_kmh"], 7.2)

    def test_station_and_time(self):
        out = normalize.format_feed(feed()["data"])
        self.assertEqual(out["station"]["id"], 1234)
        self.assertEqual(out["measured_at"]["unix"], 1792564200)
        self.assertEqual(out["category"], "Moderate")

    def test_num_handles_junk(self):
        self.assertIsNone(normalize.num("-"))
        self.assertIsNone(normalize.num(None))
        self.assertIsNone(normalize.num(float("nan")))
        self.assertEqual(normalize.num("12.5"), 12.5)


if __name__ == "__main__":
    unittest.main()
