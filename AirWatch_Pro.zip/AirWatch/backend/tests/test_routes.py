import unittest
from unittest import mock

import requests

from app import create_app, storage, waqi
from tests.base import DbTestCase, Fake, feed


class RouteTests(DbTestCase):
    def setUp(self):
        super().setUp()
        self.c = create_app(testing=True).test_client()

    def get(self, url, resp=None, side_effect=None):
        with mock.patch.object(waqi._session, "get", return_value=resp, side_effect=side_effect):
            return self.c.get(url)

    def test_health(self):
        r = self.c.get("/api/health")
        self.assertEqual(r.status_code, 200)
        self.assertTrue(r.get_json()["token_configured"])
        self.assertNotIn("SECRET123", r.get_data(as_text=True))

    def test_aqi_success_records_history_and_tracks_station(self):
        r = self.get("/api/aqi?city=Dehradun", Fake(feed()))
        j = r.get_json()
        self.assertEqual((r.status_code, j["status"], j["aqi"], j["category"]), (200, "success", 85, "Moderate"))
        self.assertEqual(j["station"]["id"], 1234)
        self.assertEqual(storage.counts("1234"), {"waqi": 1})
        self.assertIsNotNone(storage.get_station("1234"))

    def test_offline_station_response(self):
        j = self.get("/api/aqi?city=x", Fake(feed(aqi="-"))).get_json()
        self.assertFalse(j["available"])
        self.assertIsNone(j["aqi"])

    def test_location_validation(self):
        for q in ("", "?lat=abc&lon=1", "?lat=95&lon=1", "?lat=1&lon=200", "?lat=nan&lon=1", "?lat=1"):
            r = self.c.get("/api/location" + q)
            self.assertEqual(r.status_code, 400, q)
            self.assertEqual(r.get_json()["code"], "bad_request")

    def test_location_ok(self):
        r = self.get("/api/location?lat=30.3&lon=78.0", Fake(feed()))
        self.assertEqual(r.status_code, 200)

    def test_errors_use_correct_status_and_hide_secrets(self):
        cases = [
            (Fake({"status": "error", "data": "Unknown station"}), 404),
            (Fake(None, 500), 502),
            (Fake({"status": "error", "data": "Invalid key"}), 503),
        ]
        for resp, code in cases:
            waqi.clear_cache()
            r = self.get("/api/aqi?city=q", resp)
            self.assertEqual(r.status_code, code)
            self.assertNotIn("SECRET123", r.get_data(as_text=True))
        waqi.clear_cache()
        r = self.get("/api/aqi?city=q", side_effect=requests.ConnectionError("https://x/?token=SECRET123"))
        self.assertEqual(r.status_code, 502)
        self.assertNotIn("SECRET123", r.get_data(as_text=True))

    def test_unexpected_error_is_generic(self):
        with mock.patch("app.routes.normalize.format_feed", side_effect=RuntimeError("secret internals")):
            r = self.get("/api/aqi?city=q", Fake(feed()))
        self.assertEqual(r.status_code, 500)
        self.assertNotIn("secret internals", r.get_data(as_text=True))

    def test_history_and_forecast_validation(self):
        self.assertEqual(self.c.get("/api/history?station=abc").status_code, 400)
        self.assertEqual(self.c.get("/api/forecast?station=1").status_code, 404)   # not tracked yet
        self.assertEqual(self.c.get("/api/history?station=1").get_json()["points"], [])

    def test_stations_endpoint(self):
        body = {"status": "ok", "data": [
            {"lat": 30.3, "lon": 78.0, "uid": 1, "aqi": "85", "station": {"name": "A"}},
            {"lat": 30.4, "lon": 78.1, "uid": 2, "aqi": "-", "station": {"name": "offline"}}]}
        j = self.get("/api/stations?bounds=30,77,31,79", Fake(body)).get_json()
        self.assertEqual([s["id"] for s in j["stations"]], [1])
        self.assertEqual(self.c.get("/api/stations?bounds=1,2").status_code, 400)

    def test_cors_only_for_allowed_origin(self):
        ok = self.c.get("/api/health", headers={"Origin": "http://localhost:5173"})
        bad = self.c.get("/api/health", headers={"Origin": "http://evil.example"})
        self.assertEqual(ok.headers.get("Access-Control-Allow-Origin"), "http://localhost:5173")
        self.assertIsNone(bad.headers.get("Access-Control-Allow-Origin"))

    def test_unknown_endpoint_is_json(self):
        r = self.c.get("/api/nope")
        self.assertEqual((r.status_code, r.get_json()["code"]), (404, "not_found"))


if __name__ == "__main__":
    unittest.main()
