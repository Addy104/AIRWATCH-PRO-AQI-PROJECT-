import json
import time
import unittest

import numpy as np

from app import openmeteo, storage
from app.ml import forecasting as f
from tests.base import DbTestCase


def seed(station, hours, source="waqi", gap=None):
    """TEST DATA ONLY: a daily pattern with noise."""
    rng = np.random.default_rng(1)
    now = int(time.time()) // 3600 * 3600
    rows, level = [], 150.0
    for k in range(hours, 0, -1):
        if gap and gap[0] <= k < gap[1]:
            continue
        ts = now - k * 3600
        hr = (ts // 3600 + 5) % 24
        level = 0.93 * level + 0.07 * 150 + rng.normal(0, 8)
        aqi = max(20, level + 35 * np.exp(-((hr - 9) ** 2) / 8) + 55 * np.exp(-(((hr - 10) + 12) % 24 - 12) ** 2 / 10) + rng.normal(0, 6))
        rows.append({"ts": ts, "aqi": float(aqi), "temp": 24 + 6 * np.sin((hr - 9) / 24 * 2 * np.pi),
                     "humidity": 55 - 15 * np.sin((hr - 9) / 24 * 2 * np.pi), "wind": 2.0, "source": source})
    storage.save_rows(station, rows)


class ForecastTests(DbTestCase):
    def test_too_little_history_is_reported_not_invented(self):
        seed("1", 40)
        r = f.train_and_forecast("1")
        self.assertEqual((r["status"], r["available"], r["required"]), ("insufficient_data", 40, 168))
        self.assertNotIn("forecast", r)

    def test_forecast_shape_and_honest_metrics(self):
        seed("1", 240)
        r = f.train_and_forecast("1")
        self.assertEqual(r["status"], "ok")
        self.assertEqual(len(r["forecast"]), 24)
        self.assertTrue(all(p["low"] <= p["ensemble"] <= p["high"] for p in r["forecast"]))
        self.assertTrue(all(0 <= p["ensemble"] <= 500 for p in r["forecast"]))
        m = r["metrics"]
        self.assertLess(m["rf_mae"], m["persistence_mae"])            # beats "same as now" on held-out hours
        self.assertGreaterEqual(m["validation_hours"], 12)
        json.dumps(r, allow_nan=False)                                  # strictly valid JSON

    def test_short_gaps_are_filled_long_gaps_are_not(self):
        seed("1", 240, gap=(150, 152))                                  # 2 h hole: interpolated
        df = f.load_hourly("1")
        self.assertEqual(df["aqi"].isna().sum(), 0)
        storage.save_rows("2", [])
        seed("2", 240, gap=(150, 160))                                  # 10 h hole: left empty
        df = f.load_hourly("2")
        self.assertGreaterEqual(df["aqi"].isna().sum(), 7)

    def test_validation_hours_never_overlap_training_windows(self):
        seed("1", 240)
        df = f.load_hourly("1")
        orig = f.usable_origins(df, f.targets(df))
        train, val = f.split(orig)
        self.assertGreaterEqual(val[0] - train[-1], f.H)

    def test_service_trains_in_background(self):
        seed("1", 240)
        f.service.invalidate("1")
        self.assertEqual(f.service.get("1")["status"], "training")
        for _ in range(60):
            time.sleep(0.5)
            out = f.service.get("1")
            if out["status"] != "training":
                break
        self.assertEqual(out["status"], "ok")


class OpenMeteoTests(unittest.TestCase):
    def test_parse_keeps_past_hours_and_skips_missing(self):
        air = {"hourly": {"time": ["2026-10-20T00:00", "2026-10-20T01:00", "2026-10-20T02:00"], "us_aqi": [90, None, 95]}}
        wx = {"hourly": {"time": ["2026-10-20T00:00", "2026-10-20T01:00", "2026-10-20T02:00"],
                         "temperature_2m": [20, 19, 18], "relative_humidity_2m": [50, 55, 60], "wind_speed_10m": [1, 2, 3]}}
        import calendar, time as t
        now = calendar.timegm(t.strptime("2026-10-20T01:30", "%Y-%m-%dT%H:%M"))
        rows = openmeteo.parse(air, wx, now=now)
        self.assertEqual([(r["aqi"], r["temp"]) for r in rows], [(90.0, 20.0)])
        self.assertEqual(rows[0]["source"], "open-meteo")


if __name__ == "__main__":
    unittest.main()
