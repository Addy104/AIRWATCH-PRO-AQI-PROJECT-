"""Development server.  For real use run:  waitress-serve --port=5000 run:app   (Windows)
                                          gunicorn -w 1 -b 127.0.0.1:5000 run:app   (Linux/Mac)
Use ONE worker: the collector thread and model cache live inside the process."""
from app import create_app
from app.config import settings

app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=settings.DEBUG)
