"""US EPA AQI scale, which is the scale WAQI reports, plus health advice for each level.

WAQI values are on the US scale, so categories must use this scale. Using the Indian CPCB
categories (Satisfactory, Poor...) on WAQI numbers would label the same air differently.
"""

LEVELS = [  # (name, highest AQI in this level)
    ("Good", 50),
    ("Moderate", 100),
    ("Unhealthy for Sensitive Groups", 150),
    ("Unhealthy", 200),
    ("Very Unhealthy", 300),
    ("Hazardous", 500),
]


def level_of(aqi):
    """Index 0-5, or None when there is no reading."""
    if aqi is None:
        return None
    for i, (_, top) in enumerate(LEVELS):
        if aqi <= top:
            return i
    return len(LEVELS) - 1


def name_of(level):
    return None if level is None else LEVELS[level][0]


SUMMARY = [
    "Air quality is good. Normal outdoor activity is fine.",
    "Air quality is acceptable. Unusually sensitive people may notice effects.",
    "Sensitive groups may feel effects. Most people are not likely to be affected.",
    "Everyone may begin to feel effects. Sensitive groups may feel more serious ones.",
    "Health alert. The risk of effects is higher for everyone.",
    "Health emergency. Everyone is likely to be affected.",
]

# status: ok / caution / urgent
_ACTIONS = [
    [("Outdoor activity", "ok", "All outdoor activity is fine."),
     ("Mask", "ok", "Not needed."),
     ("Windows", "ok", "Keep open for fresh air."),
     ("Air purifier", "ok", "Not needed."),
     ("Watch for", "ok", "No symptoms expected.")],
    [("Outdoor activity", "ok", "Fine for most people. Very sensitive people can shorten long efforts."),
     ("Mask", "ok", "Optional."),
     ("Windows", "ok", "Open for ventilation."),
     ("Air purifier", "ok", "Optional in bedrooms."),
     ("Watch for", "ok", "Mild breathing discomfort in people with lung conditions.")],
    [("Outdoor activity", "caution", "Sensitive groups should shorten or lighten outdoor exercise."),
     ("Mask", "caution", "Sensitive groups can wear an N95 near traffic."),
     ("Windows", "caution", "Ventilate briefly at off-peak hours."),
     ("Air purifier", "caution", "Run one where sensitive people sleep or work."),
     ("Watch for", "caution", "Cough, throat irritation or wheezing. Rest if they start.")],
    [("Outdoor activity", "caution", "Cut back on long or hard outdoor exercise. Choose parks and quiet routes."),
     ("Mask", "caution", "Wear an N95 outdoors, especially near traffic."),
     ("Windows", "urgent", "Keep them closed during the worst hours."),
     ("Air purifier", "caution", "Run continuously with doors closed."),
     ("Watch for", "caution", "Chest tightness or a persistent cough. See a doctor if it worsens.")],
    [("Outdoor activity", "urgent", "Avoid outdoor exertion. Move workouts indoors."),
     ("Mask", "urgent", "N95 or better for every outdoor trip."),
     ("Windows", "urgent", "Keep them closed."),
     ("Air purifier", "caution", "Run on high and replace clogged filters."),
     ("Watch for", "urgent", "Get medical care for breathlessness, chest pain or dizziness.")],
    [("Outdoor activity", "urgent", "Stay indoors. Avoid all outdoor activity."),
     ("Mask", "urgent", "N95 or FFP2 even for brief exposure. Children and older adults stay in."),
     ("Windows", "urgent", "Keep them sealed."),
     ("Air purifier", "urgent", "Run on high in one clean room and stay there."),
     ("Watch for", "urgent", "Treat breathlessness or chest pain as urgent and call a doctor.")],
]

SENSITIVE = [
    "No special precautions.",
    "Unusually sensitive people should consider shorter outdoor activity.",
    "Children, older adults and people with asthma or heart and lung disease should reduce prolonged outdoor exertion.",
    "Sensitive groups should avoid prolonged outdoor exertion and stay indoors when possible.",
    "Sensitive groups should stay indoors and keep activity light.",
    "Sensitive groups should remain indoors in clean air and seek care if symptoms appear.",
]


def advice_for(level):
    if level is None:
        return {"summary": "No current reading is available for this station.", "actions": [], "sensitive": ""}
    return {
        "summary": SUMMARY[level],
        "actions": [{"topic": t, "status": s, "text": x} for t, s, x in _ACTIONS[level]],
        "sensitive": SENSITIVE[level],
    }
