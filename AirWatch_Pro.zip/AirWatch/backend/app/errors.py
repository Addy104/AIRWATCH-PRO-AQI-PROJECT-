"""API errors. Messages here are safe to show to users: they never contain URLs or tokens."""


class ApiError(Exception):
    status = 500
    code = "internal_error"

    def __init__(self, message=None):
        super().__init__(message or self.__class__.__doc__)
        self.message = message or self.__class__.__doc__


class BadRequest(ApiError):
    """Invalid request."""
    status, code = 400, "bad_request"


class NotFound(ApiError):
    """Station not found."""
    status, code = 404, "not_found"


class NotConfigured(ApiError):
    """The server is missing its WAQI token. Add WAQI_TOKEN to backend/.env and restart."""
    status, code = 503, "not_configured"


class UpstreamUnavailable(ApiError):
    """The air-quality provider (WAQI) is not responding. Try again in a minute."""
    status, code = 502, "upstream_unavailable"
