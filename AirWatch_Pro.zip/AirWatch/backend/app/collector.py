"""Saves readings so the models have history. Every station a user opens is tracked automatically."""
import logging
import threading

from . import normalize, openmeteo, storage, waqi
from .config import settings
from .errors import ApiError

log = logging.getLogger(__name__)
_wake = threading.Event()
_stop = threading.Event()
_thread = None


def record_feed(data):
    """Store one WAQI feed and track its station. Returns the station id (or None)."""
    idx = data.get("idx")
    if idx is None:
        return None
    sid = str(idx)
    rd = normalize.reading_from_feed(data)
    city = data.get("city") or {}
    geo = city.get("geo") or [None, None]
    is_new = storage.upsert_station(sid, city.get("name"), normalize.num(geo[0]), normalize.num(geo[1]))
    rd["source"] = "waqi"
    storage.save_rows(sid, [rd])
    if is_new:
        _wake.set()                      # start the history bootstrap now, not at the next cycle
    return sid


def run_cycle():
    for st in storage.tracked_stations():
        try:
            if not st["backfilled"]:
                openmeteo.backfill(st["id"], st["lat"], st["lon"])
                storage.mark_backfilled(st["id"])
            data, _ = waqi.feed_idx(st["id"])
            record_feed(data)
        except ApiError as e:
            log.warning("collect %s: %s", st["id"], e.code)
        except Exception:
            log.exception("collect %s failed", st["id"])


def _loop():
    while not _stop.is_set():
        try:
            run_cycle()
        except Exception:
            log.exception("collector cycle failed")
        _wake.wait(settings.COLLECT_EVERY_MIN * 60)
        _wake.clear()


def start():
    global _thread
    if _thread and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, name="collector", daemon=True)
    _thread.start()


def status():
    return {"running": bool(_thread and _thread.is_alive()), "every_min": settings.COLLECT_EVERY_MIN}
