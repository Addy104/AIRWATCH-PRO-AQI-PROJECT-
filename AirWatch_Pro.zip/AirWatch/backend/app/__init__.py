import logging

from flask import Flask, jsonify, request

from . import collector
from .config import settings
from .errors import ApiError
from .routes import api

log = logging.getLogger("airwatch")


def create_app(testing=False):
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    app = Flask(__name__)
    app.config["TESTING"] = testing
    app.json.sort_keys = False
    app.register_blueprint(api, url_prefix="/api")

    @app.errorhandler(ApiError)
    def api_error(e):
        return jsonify({"status": "error", "code": e.code, "message": e.message}), e.status

    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"status": "error", "code": "not_found", "message": "Unknown endpoint."}), 404

    @app.errorhandler(405)
    def bad_method(_):
        return jsonify({"status": "error", "code": "method_not_allowed", "message": "Method not allowed."}), 405

    @app.errorhandler(Exception)
    def unexpected(e):
        log.exception("Unhandled error")                      # details stay in the server log
        return jsonify({"status": "error", "code": "internal_error",
                        "message": "Something went wrong on the server."}), 500

    @app.after_request
    def headers(resp):
        origin = request.headers.get("Origin")
        if origin and origin in settings.CORS_ORIGINS:
            resp.headers["Access-Control-Allow-Origin"] = origin
            resp.headers["Vary"] = "Origin"
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["Cache-Control"] = "no-store"
        return resp

    if settings.ENABLE_COLLECTOR and not testing:
        import os
        # With the debug reloader, Flask runs this file twice. Start the collector only in the real process.
        if not settings.DEBUG or os.environ.get("WERKZEUG_RUN_MAIN") == "true":
            collector.start()
    return app
