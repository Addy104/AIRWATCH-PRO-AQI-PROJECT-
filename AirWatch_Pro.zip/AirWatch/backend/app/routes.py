import math

from flask import Blueprint, jsonify, request

from . import collector, normalize, scale, storage, waqi
from .config import settings
from .errors import BadRequest, NotFound
from .ml.forecasting import service as forecast_service

api = Blueprint("api", __name__)


def _clean(obj):
    """JSON has no NaN. Replace NaN/inf with null so the browser can parse every response."""
    if isinstance(obj, float):
        return obj if math.isfinite(obj) else None
    if isinstance(obj, dict):
        return {k: _clean(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_clean(v) for v in obj]
    return obj


def _float(name, lo, hi):
    raw = request.args.get(name)
    if raw is None or raw == "":
        raise BadRequest(f"'{name}' is required.")
    try:
        v = float(raw)
    except ValueError:
        raise BadRequest(f"'{name}' must be a number.") from None
    if not (lo <= v <= hi) or not math.isfinite(v):
        raise BadRequest(f"'{name}' must be between {lo} and {hi}.")
    return v


def _respond(data, stale):
    collector.record_feed(data)
    return jsonify(_clean(normalize.format_feed(data, stale)))


@api.get("/health")
def health():
    return jsonify({
        "status": "ok", "service": "AirWatch API", "provider": "WAQI",
        "token_configured": bool(settings.WAQI_TOKEN),
        "collector": collector.status(),
        "stations_tracked": len(storage.tracked_stations()),
    })


@api.get("/aqi")
def aqi():
    city = request.args.get("city", "Dehradun")
    data, stale = waqi.feed_city(city)
    return _respond(data, stale)


@api.get("/location")
def location():
    data, stale = waqi.feed_geo(_float("lat", -90, 90), _float("lon", -180, 180))
    return _respond(data, stale)


@api.get("/history")
def history():
    sid = request.args.get("station", "")
    if not sid.isdigit():
        raise BadRequest("'station' must be a WAQI station id.")
    try:
        hours = int(request.args.get("hours", 48))
    except ValueError:
        raise BadRequest("'hours' must be a whole number.") from None
    hours = max(1, min(hours, 24 * 14))
    rows = storage.recent(sid, hours)
    return jsonify({"status": "success", "station": sid, "hours": hours,
                    "points": [{"ts": r["ts"], "aqi": r["aqi"], "level": scale.level_of(r["aqi"]),
                                "modelled": r["source"] != "waqi"} for r in rows]})


@api.get("/forecast")
def forecast():
    sid = request.args.get("station", "")
    if not sid.isdigit():
        raise BadRequest("'station' must be a WAQI station id.")
    if storage.get_station(sid) is None:
        raise NotFound("Open this station on the dashboard first so it can start collecting history.")
    if request.args.get("refresh") in ("1", "true"):
        forecast_service.invalidate(sid)
    res = forecast_service.get(sid)
    return jsonify(_clean(res))


@api.get("/stations")
def stations():
    """Stations inside a map window, from WAQI's map endpoint (one request)."""
    try:
        lat1, lon1, lat2, lon2 = (float(x) for x in request.args.get("bounds", "").split(","))
    except ValueError:
        raise BadRequest("'bounds' must be lat1,lon1,lat2,lon2.") from None
    if not (-90 <= lat1 <= 90 and -90 <= lat2 <= 90 and -180 <= lon1 <= 180 and -180 <= lon2 <= 180):
        raise BadRequest("'bounds' is outside the valid range.")
    data, stale = waqi.map_bounds(lat1, lon1, lat2, lon2)
    out = []
    for s in (data or [])[:300]:
        v = normalize.num(s.get("aqi"))
        if v is None or s.get("lat") is None or s.get("lon") is None:
            continue
        out.append({"id": s.get("uid"), "lat": s["lat"], "lon": s["lon"], "aqi": v,
                    "level": scale.level_of(v), "name": (s.get("station") or {}).get("name")})
    return jsonify({"status": "success", "stale": stale, "stations": out})
