"""Random Forest + LSTM 24-hour AQI forecasting from stored hourly history.

Rules this module follows:
  * It never invents data. With too little history it returns status "insufficient_data".
  * Gaps of up to 3 hours are interpolated; longer gaps are left empty and those windows are skipped.
  * Both models are scored on the same held-out, most recent hours, against a "same as now" baseline.
"""
from __future__ import annotations

import threading
import time

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor

from .. import storage as db
from ..config import settings as config

H = 24            # forecast horizon, hours
WIN = 48          # LSTM look-back, hours
MIN_SAMPLES = 40  # usable training windows needed
WX = ["temp", "humidity", "wind"]
SEQ = ["aqi"] + WX

try:  # LSTM is optional at import time so the Random Forest still works without PyTorch.
    import torch
    from torch import nn
    HAS_TORCH = True
except Exception:  # pragma: no cover
    HAS_TORCH = False


# --------------------------------------------------------------------------- data
def load_hourly(station: str) -> pd.DataFrame:
    df = db.read(station)
    if df.empty:
        return df
    df = df[~df.index.duplicated(keep="last")]
    df = df.reindex(pd.date_range(df.index.min(), df.index.max(), freq="h", tz="UTC"))
    df["aqi"] = df["aqi"].interpolate(limit=3, limit_area="inside")
    for c in WX:
        df[c] = df[c].ffill(limit=6)
        df[c] = df[c].fillna(df[c].median() if df[c].notna().any() else 0.0)
    return df


def _time_feats(idx: pd.DatetimeIndex) -> np.ndarray:
    h, d = idx.hour.to_numpy(), idx.dayofweek.to_numpy()
    return np.column_stack([np.sin(2 * np.pi * h / 24), np.cos(2 * np.pi * h / 24),
                            np.sin(2 * np.pi * d / 7), np.cos(2 * np.pi * d / 7)])


def rf_features(df: pd.DataFrame) -> np.ndarray:
    a = df["aqi"]
    cols = [a.shift(l) for l in (0, 1, 2, 3, 6, 12, 24)]
    cols += [a.rolling(6).mean(), a.rolling(24).mean(), a.rolling(24).std()]
    cols += [df[c] for c in WX]
    return np.column_stack([np.column_stack(cols), _time_feats(df.index)])


def targets(df: pd.DataFrame) -> np.ndarray:
    a = df["aqi"]
    return np.column_stack([a.shift(-h) for h in range(1, H + 1)])


def seq_features(df: pd.DataFrame) -> np.ndarray:
    t = _time_feats(df.index)[:, :2]
    return np.column_stack([df[SEQ].to_numpy(float), t])


def usable_origins(df: pd.DataFrame, Y: np.ndarray) -> list[int]:
    a = df["aqi"].to_numpy(float)
    ok = ~np.isnan(a)
    out = []
    for i in range(WIN - 1, len(df) - H):
        if ok[i - WIN + 1: i + 1].all() and not np.isnan(Y[i]).any():
            out.append(i)
    return out


def split(origins: list[int]) -> tuple[list[int], list[int]]:
    """Chronological split: last 20% validate, with a 24 h gap so no window overlaps."""
    nv = max(12, int(0.2 * len(origins)))
    val = origins[-nv:]
    train = [i for i in origins[:-nv] if i < val[0] - H]
    return train, val


# --------------------------------------------------------------------------- LSTM
if HAS_TORCH:
    class _Net(nn.Module):
        def __init__(self, f: int, hidden: int = 64):
            super().__init__()
            self.lstm = nn.LSTM(f, hidden, batch_first=True)
            self.drop = nn.Dropout(0.1)
            self.out = nn.Linear(hidden, H)

        def forward(self, x):
            o, _ = self.lstm(x)
            return self.out(self.drop(o[:, -1]))


class LSTMForecaster:
    """Looks at the last 48 h of AQI, temperature, humidity, wind and time of day,
    and predicts the next 24 h as changes from the latest AQI."""

    def __init__(self):
        self.net = None
        self.mu = self.sd = None
        self.epochs = 0

    def _windows(self, X: np.ndarray, idx: list[int]) -> np.ndarray:
        Xs = (X - self.mu) / self.sd
        return np.stack([Xs[i - WIN + 1: i + 1] for i in idx]).astype(np.float32)

    def _fit(self, X, A, Y, idx, val_idx=None, epochs=120, patience=15, seed=0):
        torch.manual_seed(seed)
        w = torch.from_numpy(self._windows(X, idx))
        y = torch.from_numpy(((Y[idx] - A[idx, None]) / self.sd_a).astype(np.float32))
        net = _Net(w.shape[2])
        opt = torch.optim.Adam(net.parameters(), lr=3e-3, weight_decay=1e-4)
        lossf = nn.L1Loss()
        best, best_ep, best_state, bad = 1e18, 0, None, 0
        if val_idx is not None:
            wv = torch.from_numpy(self._windows(X, val_idx))
            yv = torch.from_numpy(((Y[val_idx] - A[val_idx, None]) / self.sd_a).astype(np.float32))
        for ep in range(1, epochs + 1):
            net.train()
            perm = torch.randperm(len(w))
            for b in range(0, len(w), 32):
                k = perm[b: b + 32]
                opt.zero_grad()
                lossf(net(w[k]), y[k]).backward()
                nn.utils.clip_grad_norm_(net.parameters(), 1.0)
                opt.step()
            if val_idx is not None:
                net.eval()
                with torch.no_grad():
                    v = lossf(net(wv), yv).item()
                if v < best - 1e-4:
                    best, best_ep, bad = v, ep, 0
                    best_state = {k: t.clone() for k, t in net.state_dict().items()}
                else:
                    bad += 1
                    if bad >= patience:
                        break
        if best_state is not None:
            net.load_state_dict(best_state)
        net.eval()
        return net, (best_ep or epochs)

    def fit(self, df, X, A, Y, train_idx, val_idx, all_idx):
        """Pick the epoch count on the validation hours, then refit on every window."""
        rows = X[: max(train_idx) + 1]
        self.mu, self.sd = np.nanmean(rows, 0), np.nanstd(rows, 0) + 1e-6
        self.sd_a = float(self.sd[0])
        net, ep = self._fit(X, A, Y, train_idx, val_idx)
        val_pred = self._predict_with(net, X, A, val_idx)
        self.epochs = max(10, ep)
        self.net, _ = self._fit(X, A, Y, all_idx, None, epochs=self.epochs)
        return val_pred

    def _predict_with(self, net, X, A, idx):
        w = torch.from_numpy(self._windows(X, idx))
        with torch.no_grad():
            d = net(w).numpy()
        return A[idx, None] + d * self.sd_a

    def predict(self, X, A, i):
        return self._predict_with(self.net, X, A, [i])[0]


# --------------------------------------------------------------------------- training + forecast
def train_and_forecast(station: str) -> dict:
    df = load_hourly(station)
    counts = db.counts(station)
    real = sum(counts.values())
    base = {"station": station, "available": real, "required": config.MIN_RECORDS, "sources": counts}
    if real < config.MIN_RECORDS:
        return {**base, "status": "insufficient_data"}

    A = df["aqi"].to_numpy(float)
    Y = targets(df)
    F = rf_features(df)
    X = seq_features(df)
    origins = usable_origins(df, Y)
    if len(origins) < MIN_SAMPLES:
        return {**base, "status": "insufficient_data", "usable_windows": len(origins),
                "detail": f"Only {len(origins)} continuous windows (need {MIN_SAMPLES}). Recent data has gaps."}

    train, val = split(origins)
    if len(train) < 20:
        return {**base, "status": "insufficient_data", "usable_windows": len(origins),
                "detail": "Not enough continuous history to hold back validation hours."}

    # median-fill any leftover NaN in RF features using training rows only
    med = np.nanmedian(F[train], axis=0)
    fill = lambda M: np.where(np.isnan(M), med, M)
    Ff = fill(F)

    def make_rf():
        return RandomForestRegressor(n_estimators=300, min_samples_leaf=2, max_features=0.6,
                                     n_jobs=-1, random_state=0)

    rf = make_rf().fit(Ff[train], Y[train])
    rf_val = rf.predict(Ff[val])
    rf = make_rf().fit(Ff[origins], Y[origins])           # refit on everything

    yv = Y[val]
    persist_val = np.repeat(A[val][:, None], H, axis=1)
    mae_h = lambda p: np.abs(p - yv).mean(0)

    lstm, lstm_val, lstm_note = None, None, None
    if HAS_TORCH:
        try:
            lstm = LSTMForecaster()
            lstm_val = lstm.fit(df, X, A, Y, train, val, origins)
        except Exception as e:  # keep the Random Forest alive if the LSTM fails
            lstm, lstm_val, lstm_note = None, None, f"LSTM failed: {e}"
    else:
        lstm_note = "PyTorch is not installed, so the LSTM was skipped."

    # ensemble weights from validation error (lower error -> larger weight)
    parts = {"rf": rf_val}
    if lstm_val is not None:
        parts["lstm"] = lstm_val
    inv = {k: 1.0 / max(mae_h(v).mean(), 1e-6) for k, v in parts.items()}
    tot = sum(inv.values())
    w = {k: inv[k] / tot for k in inv}
    ens_val = sum(w[k] * parts[k] for k in parts)
    ens_mae_h = np.maximum.accumulate(mae_h(ens_val))     # error never shrinks with horizon

    # forecast from the latest hour
    last = len(df) - 1
    if np.isnan(A[last - WIN + 1: last + 1]).any():
        return {**base, "status": "insufficient_data",
                "detail": "The most recent 48 hours contain gaps. Collect a few more readings."}
    rf_p = rf.predict(fill(F[last: last + 1]))[0]
    preds = {"rf": rf_p}
    if lstm is not None:
        preds["lstm"] = lstm.predict(X, A, last)
    ens_p = sum(w[k] * preds[k] for k in preds)
    hw = 1.6 * ens_mae_h                                   # about an 80% range from validation error

    clip = lambda v: np.clip(v, 0, 500)
    t0 = df.index[last]
    fc = []
    for h in range(H):
        t = t0 + pd.Timedelta(hours=h + 1)
        fc.append({
            "ts": t.isoformat(),
            "rf": round(float(clip(preds["rf"][h])), 1),
            "lstm": round(float(clip(preds["lstm"][h])), 1) if "lstm" in preds else None,
            "ensemble": round(float(clip(ens_p[h])), 1),
            "low": round(float(clip(ens_p[h] - hw[h])), 1),
            "high": round(float(clip(ens_p[h] + hw[h])), 1),
        })
    hist_df = df["aqi"].dropna().iloc[-72:]
    history = [{"ts": t.isoformat(), "aqi": round(float(v), 1)} for t, v in hist_df.items()]

    metrics = {
        "validation_hours": len(val),
        "training_windows": len(train),
        "persistence_mae": round(float(mae_h(persist_val).mean()), 1),
        "rf_mae": round(float(mae_h(rf_val).mean()), 1),
        "lstm_mae": round(float(mae_h(lstm_val).mean()), 1) if lstm_val is not None else None,
        "ensemble_mae": round(float(mae_h(ens_val).mean()), 1),
        "weights": {k: round(float(v), 2) for k, v in w.items()},
        "lstm_epochs": lstm.epochs if lstm is not None else None,
    }
    stale_h = (pd.Timestamp.now(tz="UTC") - t0).total_seconds() / 3600
    return {**base, "status": "ok", "trained_at": pd.Timestamp.now(tz="UTC").isoformat(),
            "last_reading_at": t0.isoformat(), "stale_hours": round(stale_h, 1),
            "history": history, "forecast": fc, "metrics": metrics, "note": lstm_note}


# --------------------------------------------------------------------------- service (cache + background training)
class ForecastService:
    def __init__(self):
        self._cache: dict[str, dict] = {}
        self._busy: set[str] = set()
        self._lock = threading.Lock()

    def get(self, station: str) -> dict:
        with self._lock:
            cached = self._cache.get(station)
            fresh = cached and cached.get("status") == "ok" and \
                (time.time() - cached["_at"]) < config.RETRAIN_HOURS * 3600
            if fresh or station in self._busy:
                return self._out(cached, station, training=station in self._busy)
            self._busy.add(station)
        threading.Thread(target=self._run, args=(station,), daemon=True).start()
        return self._out(cached, station, training=True)

    def _run(self, station: str):
        try:
            res = train_and_forecast(station)
        except Exception as e:  # never leave the UI waiting forever
            res = {"station": station, "status": "error", "detail": str(e)}
        res["_at"] = time.time()
        with self._lock:
            self._cache[station] = res
            self._busy.discard(station)

    @staticmethod
    def _out(res, station, training):
        if res is None:
            return {"station": station, "status": "training"}
        out = {k: v for k, v in res.items() if not k.startswith("_")}
        if training and out.get("status") == "ok":
            out["refreshing"] = True
        return out

    def invalidate(self, station: str):
        with self._lock:
            self._cache.pop(station, None)


service = ForecastService()
