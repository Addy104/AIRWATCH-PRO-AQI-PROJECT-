"""Turns a WAQI feed into the JSON the dashboard uses. Handles offline stations and units."""
from . import scale

POLLUTANTS = ("pm25", "pm10", "no2", "o3", "so2", "co")


def num(x):
    """WAQI sends numbers, numeric strings, or '-' when a sensor is offline."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return None
    return v if v == v else None


def _v(iaqi, key):
    x = iaqi.get(key)
    return num(x.get("v")) if isinstance(x, dict) else None


def reading_from_feed(data):
    """The raw numbers stored in the history table."""
    iaqi = data.get("iaqi") or {}
    t = data.get("time") or {}
    wind = _v(iaqi, "w")
    return {
        "ts": int(t["v"]) if num(t.get("v")) else None,
        "aqi": num(data.get("aqi")),
        "pm25": _v(iaqi, "pm25"), "pm10": _v(iaqi, "pm10"), "no2": _v(iaqi, "no2"),
        "o3": _v(iaqi, "o3"), "so2": _v(iaqi, "so2"), "co": _v(iaqi, "co"),
        "temp": _v(iaqi, "t"), "humidity": _v(iaqi, "h"), "wind": wind,   # wind stays in m/s
        "pressure": _v(iaqi, "p"),
    }


def format_feed(data, stale=False):
    city = data.get("city") or {}
    geo = city.get("geo") or [None, None]
    t = data.get("time") or {}
    rd = reading_from_feed(data)
    level = scale.level_of(rd["aqi"])
    pollutants = {}
    for k in POLLUTANTS:
        v = rd[k]
        pollutants[k] = {"value": v, "level": scale.level_of(v), "category": scale.name_of(scale.level_of(v))}
    wind = rd["wind"]
    return {
        "status": "success",
        "provider": "WAQI",
        "scale": "US EPA AQI",
        "stale": bool(stale),
        "available": rd["aqi"] is not None,
        "aqi": rd["aqi"],
        "level": level,
        "category": scale.name_of(level),
        "dominant": data.get("dominentpol"),          # WAQI's own spelling of the field
        "advice": scale.advice_for(level),
        "station": {
            "id": data.get("idx"),
            "name": city.get("name"),
            "url": city.get("url"),
            "latitude": num(geo[0]) if len(geo) > 0 else None,
            "longitude": num(geo[1]) if len(geo) > 1 else None,
        },
        "measured_at": {"iso": t.get("iso"), "unix": rd["ts"], "local": t.get("s")},
        "pollutants": pollutants,
        "weather": {
            "temperature": rd["temp"],
            "humidity": rd["humidity"],
            "pressure": rd["pressure"],
            "wind_kmh": None if wind is None else round(wind * 3.6, 1),   # WAQI gives m/s
        },
    }
