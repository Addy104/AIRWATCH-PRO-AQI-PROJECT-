"""SQLite history of readings. One row per station per hour (UTC)."""
import sqlite3
import time
from contextlib import contextmanager

import pandas as pd

from .config import settings

COLS = ["aqi", "pm25", "pm10", "no2", "o3", "so2", "co", "temp", "humidity", "wind", "pressure"]

SCHEMA = f"""
CREATE TABLE IF NOT EXISTS stations (
  id TEXT PRIMARY KEY, name TEXT, lat REAL, lon REAL,
  backfilled INTEGER NOT NULL DEFAULT 0, last_seen INTEGER
);
CREATE TABLE IF NOT EXISTS readings (
  station TEXT NOT NULL,
  ts      INTEGER NOT NULL,            -- unix seconds floored to the hour (UTC)
  {", ".join(c + " REAL" for c in COLS)},
  source  TEXT NOT NULL,               -- 'waqi' = measured, 'open-meteo' = modelled backfill
  PRIMARY KEY (station, ts)
);
"""


@contextmanager
def conn():
    c = sqlite3.connect(settings.DB_PATH, timeout=30)
    c.row_factory = sqlite3.Row
    try:
        c.executescript(SCHEMA)
        yield c
        c.commit()
    finally:
        c.close()


def upsert_station(station_id, name, lat, lon):
    """Remember a station so the collector keeps recording it. Returns True if it is new."""
    with conn() as c:
        new = c.execute("SELECT 1 FROM stations WHERE id=?", (station_id,)).fetchone() is None
        c.execute(
            "INSERT INTO stations (id, name, lat, lon, last_seen) VALUES (?,?,?,?,?) "
            "ON CONFLICT(id) DO UPDATE SET name=excluded.name, lat=COALESCE(excluded.lat, lat), "
            "lon=COALESCE(excluded.lon, lon), last_seen=excluded.last_seen",
            (station_id, name, lat, lon, int(time.time())),
        )
    return new


def get_station(station_id):
    with conn() as c:
        r = c.execute("SELECT * FROM stations WHERE id=?", (station_id,)).fetchone()
    return dict(r) if r else None


def tracked_stations():
    with conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM stations")]


def mark_backfilled(station_id):
    with conn() as c:
        c.execute("UPDATE stations SET backfilled=1 WHERE id=?", (station_id,))


def save_rows(station, rows):
    """rows: dicts with ts, source and any of COLS. A measured WAQI row always replaces a modelled
    one for the same hour; a modelled row never replaces a measured one."""
    rows = [r for r in rows if r.get("ts") is not None and r.get("aqi") is not None]
    if not rows:
        return 0
    sql = (
        f"INSERT INTO readings (station, ts, {', '.join(COLS)}, source) "
        f"VALUES (?, ?, {', '.join('?' for _ in COLS)}, ?) "
        "ON CONFLICT(station, ts) DO UPDATE SET "
        + ", ".join(f"{c}=excluded.{c}" for c in COLS)
        + ", source=excluded.source WHERE excluded.source='waqi' OR readings.source<>'waqi'"
    )
    data = [(station, int(r["ts"]) // 3600 * 3600, *[r.get(c) for c in COLS], r["source"]) for r in rows]
    with conn() as c:
        c.executemany(sql, data)
    return len(data)


def read(station, days=90):
    with conn() as c:
        df = pd.read_sql_query(
            "SELECT * FROM readings WHERE station=? AND aqi IS NOT NULL AND ts >= ? ORDER BY ts",
            c, params=(station, int(time.time()) - days * 86400))
    if df.empty:
        return df
    df.index = pd.to_datetime(df["ts"], unit="s", utc=True)
    return df.drop(columns=["ts", "station"])


def counts(station):
    with conn() as c:
        rows = c.execute(
            "SELECT source, COUNT(*) n FROM readings WHERE station=? AND aqi IS NOT NULL GROUP BY source",
            (station,)).fetchall()
    return {r["source"]: r["n"] for r in rows}


def recent(station, hours):
    with conn() as c:
        rows = c.execute(
            "SELECT ts, aqi, source FROM readings WHERE station=? AND aqi IS NOT NULL AND ts >= ? ORDER BY ts",
            (station, int(time.time()) - hours * 3600)).fetchall()
    return [dict(r) for r in rows]
