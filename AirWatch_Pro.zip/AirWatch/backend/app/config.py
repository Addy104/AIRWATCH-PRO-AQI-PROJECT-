"""Settings, read from environment variables (and backend/.env if present)."""
import os
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).resolve().parent.parent / ".env")
except ImportError:  # python-dotenv is in requirements.txt; this only keeps tests runnable without it
    pass

BASE_DIR = Path(__file__).resolve().parent.parent


def _int(name, default):
    try:
        return int(os.getenv(name, default))
    except ValueError:
        return default


class Settings:
    WAQI_TOKEN = os.getenv("WAQI_TOKEN", "").strip()
    DEBUG = os.getenv("FLASK_DEBUG", "0") == "1"
    CORS_ORIGINS = [o.strip() for o in os.getenv(
        "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if o.strip()]
    DB_PATH = os.getenv("AIRWATCH_DB", str(BASE_DIR / "airwatch.db"))

    WAQI_CACHE_SECONDS = _int("WAQI_CACHE_SECONDS", 30)
    WAQI_STALE_SECONDS = _int("WAQI_STALE_SECONDS", 3600)   # serve last good data this long if WAQI is down

    ENABLE_COLLECTOR = os.getenv("ENABLE_COLLECTOR", "1") == "1"
    COLLECT_EVERY_MIN = _int("COLLECT_EVERY_MIN", 30)
    BACKFILL_DAYS = _int("BACKFILL_DAYS", 14)
    MIN_RECORDS = _int("MIN_RECORDS", 168)                  # one week of hourly readings
    RETRAIN_HOURS = _int("RETRAIN_HOURS", 6)


settings = Settings()
