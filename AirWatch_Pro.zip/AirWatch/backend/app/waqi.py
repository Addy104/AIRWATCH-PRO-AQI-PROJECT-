"""WAQI client. The token is added here, on the server, and never leaves it.

Safety rules:
  * errors are converted to ApiError with fixed messages (a raw requests error contains the full
    URL including ?token=..., which must never reach the browser),
  * user input is URL-quoted before it goes into a path,
  * responses are cached briefly and the last good one is served if WAQI is down.
"""
import logging
import threading
import time
from urllib.parse import quote

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import settings
from .errors import BadRequest, NotConfigured, NotFound, UpstreamUnavailable

log = logging.getLogger(__name__)
BASE = "https://api.waqi.info"

_session = requests.Session()
_session.mount("https://", HTTPAdapter(max_retries=Retry(
    total=2, backoff_factor=0.4, status_forcelist=(502, 503, 504), allowed_methods=("GET",))))

_cache: dict[str, tuple[float, dict]] = {}
_lock = threading.Lock()


def _call(path, params=None):
    """One WAQI request. Returns the 'data' field or raises an ApiError."""
    if not settings.WAQI_TOKEN:
        raise NotConfigured()
    try:
        r = _session.get(BASE + path, params={**(params or {}), "token": settings.WAQI_TOKEN}, timeout=(5, 15))
    except requests.RequestException as e:
        log.warning("WAQI request failed: %s", type(e).__name__)   # class name only, never the URL
        raise UpstreamUnavailable() from None
    if r.status_code >= 400:
        log.warning("WAQI returned HTTP %s", r.status_code)
        raise UpstreamUnavailable()
    try:
        body = r.json()
    except ValueError:
        raise UpstreamUnavailable() from None
    if body.get("status") != "ok":
        msg = str(body.get("data", "")).lower()
        if "unknown" in msg or "not found" in msg:
            raise NotFound("No WAQI station was found for that place.")
        if "key" in msg or "token" in msg:
            raise NotConfigured("WAQI rejected the token. Check WAQI_TOKEN in backend/.env.")
        raise UpstreamUnavailable()
    return body["data"]


def fetch(path, params=None):
    """Cached call. Returns (data, stale). stale=True means WAQI failed and an older copy was used."""
    key = path + "?" + "&".join(f"{k}={v}" for k, v in sorted((params or {}).items()))
    now = time.time()
    with _lock:
        hit = _cache.get(key)
    if hit and now - hit[0] < settings.WAQI_CACHE_SECONDS:
        return hit[1], False
    try:
        data = _call(path, params)
    except UpstreamUnavailable:
        if hit and now - hit[0] < settings.WAQI_STALE_SECONDS:
            return hit[1], True
        raise
    with _lock:
        _cache[key] = (now, data)
        if len(_cache) > 500:                       # keep memory bounded
            for k in sorted(_cache, key=lambda k: _cache[k][0])[:100]:
                _cache.pop(k, None)
    return data, False


def clear_cache():
    with _lock:
        _cache.clear()


def feed_city(city):
    city = (city or "").strip()
    if not city or len(city) > 80:
        raise BadRequest("Enter a city name of 1 to 80 characters.")
    return fetch(f"/feed/{quote(city, safe='@')}/")   # "@1234" selects a station by id


def feed_geo(lat, lon):
    return fetch(f"/feed/geo:{lat:.5f};{lon:.5f}/")


def feed_idx(idx):
    return fetch(f"/feed/@{int(idx)}/")


def map_bounds(lat1, lon1, lat2, lon2):
    return fetch("/v2/map/bounds", {"latlng": f"{lat1:.4f},{lon1:.4f},{lat2:.4f},{lon2:.4f}"})
