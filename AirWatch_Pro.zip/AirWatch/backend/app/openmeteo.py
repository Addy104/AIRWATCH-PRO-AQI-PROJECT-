"""Optional bootstrap of modelled history from Open-Meteo, so forecasts work on day one.

These rows are modelled, not measured. They are stored with source='open-meteo', never replace a
WAQI reading, and the dashboard shows how many modelled hours a forecast used. Open-Meteo gives
US AQI, the same scale as WAQI. Pollutant concentrations are not stored: Open-Meteo reports ug/m3
while WAQI reports sub-indices.
"""
import calendar
import logging
import time

import requests

from . import storage
from .config import settings

log = logging.getLogger(__name__)
AIR = "https://air-quality-api.open-meteo.com/v1/air-quality"
WEATHER = "https://api.open-meteo.com/v1/forecast"


def _num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def parse(air, wx, now=None):
    now = now or time.time()
    a, w = air["hourly"], wx["hourly"]
    wmap = {t: i for i, t in enumerate(w["time"])}
    rows = []
    for i, t in enumerate(a["time"]):
        ts = calendar.timegm(time.strptime(t, "%Y-%m-%dT%H:%M"))     # timezone=GMT
        aqi = _num(a["us_aqi"][i])
        if ts > now or aqi is None:
            continue
        j = wmap.get(t)
        rows.append({
            "ts": ts, "aqi": aqi, "source": "open-meteo",
            "temp": _num(w["temperature_2m"][j]) if j is not None else None,
            "humidity": _num(w["relative_humidity_2m"][j]) if j is not None else None,
            "wind": _num(w["wind_speed_10m"][j]) if j is not None else None,
        })
    return rows


def backfill(station_id, lat, lon, days=None):
    days = settings.BACKFILL_DAYS if days is None else days
    if days <= 0 or lat is None or lon is None:
        return 0
    common = {"latitude": lat, "longitude": lon, "past_days": min(days, 92), "forecast_days": 1, "timezone": "GMT"}
    try:
        air = requests.get(AIR, params={**common, "hourly": "us_aqi"}, timeout=30)
        wx = requests.get(WEATHER, params={**common, "wind_speed_unit": "ms",
                          "hourly": "temperature_2m,relative_humidity_2m,wind_speed_10m"}, timeout=30)
        air.raise_for_status()
        wx.raise_for_status()
        return storage.save_rows(station_id, parse(air.json(), wx.json()))
    except (requests.RequestException, KeyError, ValueError) as e:
        log.warning("Open-Meteo backfill failed for %s: %s", station_id, type(e).__name__)
        return 0
