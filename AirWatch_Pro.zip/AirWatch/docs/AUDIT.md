# What was wrong in the original project, and what changed

## Bugs fixed

| # | Problem in the original | Fix |
|---|---|---|
| 1 | **Token leak.** Any WAQI error (bad key, outage, unknown station) returned the raw exception text to the browser. That text contains the full URL including `?token=YOUR_TOKEN`. | Errors are converted to fixed, safe messages. The token is added only inside `waqi.py` and never logged. Tests assert it never appears in any response. |
| 2 | **Wrong AQI labels.** WAQI numbers are on the US scale, but the app labelled them with Indian CPCB thresholds, so AQI 164 showed "Moderate" (it is "Unhealthy" on the US scale). | One US EPA scale used everywhere, from a single backend module. |
| 3 | **Offline station showed AQI 0 "Good".** WAQI sends `"-"`; the UI turned it into 0. Missing pollutants also showed "Good". | Missing values stay `null` and show "No data". |
| 4 | **Wind in the wrong unit.** WAQI sends m/s, the UI said km/h. | Converted to km/h on the server. |
| 5 | **"My location" broke the station.** It set the city to the station's long name, which re-queried WAQI by that name and made the dropdown invalid. | Location is its own kind of selection. The dropdown shows the real station name. |
| 6 | **Stale responses could overwrite new ones** when switching stations quickly, and the old station's trend stayed on screen. | Requests are cancelled and numbered; only the newest can update the page. |
| 7 | **The "forecast" was a straight line** through minute-by-minute readings, labelled "+1h, +2h...". | Replaced by the Random Forest + LSTM forecast on hourly history. |
| 8 | **The trend was lost on every reload** (kept in browser memory) and duplicated unchanged readings. | Readings are saved hourly in SQLite and survive restarts. |
| 9 | **City name was put into the URL path unescaped.** | URL-quoted and length-checked. |
| 10 | **Every error was HTTP 500.** | 400 bad input, 404 unknown station, 502 WAQI down, 503 token missing. |
| 11 | Flask `debug=True` always on; CORS open to every website. | Debug only by setting; CORS limited to your frontend. |
| 12 | `package.json` used `"latest"` for every package, so a fresh install could break at any time. | Versions pinned. |
| 13 | Fonts named in the CSS were never loaded. `alert()` popups for errors. No keys on some lists. | Fonts linked; inline notices; keys added. |

## Added

- Station history database and background collector
- Random Forest + LSTM 24-hour forecast with honest validation and "not enough data" handling
- Real chart with axes, categories and hover; interactive Leaflet map with live stations
- Health advice from one source (backend), sensitive-groups note
- Short cache with "last good reading" fallback when WAQI is down
- 36 backend tests and chart/scale tests, README and Windows start scripts

## Not verified in the build environment

The React app was syntax- and import-checked and its chart code was unit-tested, but it was not built or opened in a browser. The LSTM was not run (PyTorch could not be installed there), and calls to the live WAQI and Open-Meteo services were tested only against simulated responses.
