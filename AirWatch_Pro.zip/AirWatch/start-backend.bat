@echo off
rem Run from the AirWatch folder. First time: creates the virtual environment and installs packages.
cd /d "%~dp0backend"
if not exist venv (
  python -m venv venv
  call venv\Scripts\activate
  pip install -r requirements.txt
) else (
  call venv\Scripts\activate
)
if not exist .env (
  copy .env.example .env >nul
  echo.
  echo Created backend\.env. Open it, replace YOUR_WAQI_TOKEN with your real token, then run this file again.
  pause
  exit /b
)
python run.py
